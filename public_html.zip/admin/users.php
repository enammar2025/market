<?php
session_start();
require_once '../config/database.php';
require_once '../classes/User.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

$message = '';
$message_type = '';

// معالجة العمليات
if ($_POST) {
    if (isset($_POST['update_user_status'])) {
        $user_id = $_POST['user_id'];
        $status = $_POST['status'];
        
        if ($user->updateUserStatus($user_id, $status)) {
            $message = 'تم تحديث حالة المستخدم بنجاح';
            $message_type = 'success';
        } else {
            $message = 'حدث خطأ في تحديث حالة المستخدم';
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['update_user_role'])) {
        $user_id = $_POST['user_id'];
        $role = $_POST['role'];
        
        if ($user->updateUserRole($user_id, $role)) {
            $message = 'تم تحديث دور المستخدم بنجاح';
            $message_type = 'success';
        } else {
            $message = 'حدث خطأ في تحديث دور المستخدم';
            $message_type = 'error';
        }
    }
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$users = $user->getAllUsers($page, 20);
$total_users = $user->getTotalUsers();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين - متجر الطاقة الكهربائية</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .admin-container { display: flex; min-height: 100vh; background: #f8f9fa; }
        .admin-content { margin-right: 280px; padding: 30px; width: calc(100% - 280px); }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
        .stat-value { font-size: 28px; font-weight: bold; color: #2c3e50; }
        .stat-label { color: #7f8c8d; font-size: 14px; margin-top: 5px; }
        .users-table { background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .table-header { background: #34495e; color: white; padding: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: right; padding: 15px; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; font-weight: bold; color: #2c3e50; }
        .user-avatar { width: 40px; height: 40px; background: #3498db; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; }
        .status-badge { padding: 4px 12px; border-radius: 15px; font-size: 12px; font-weight: bold; }
        .status-active { background: #d4edda; color: #155724; }
        .status-inactive { background: #f8d7da; color: #721c24; }
        .role-badge { padding: 4px 12px; border-radius: 15px; font-size: 12px; font-weight: bold; }
        .role-admin { background: #e1ecf4; color: #0c5460; }
        .role-customer { background: #fff3cd; color: #856404; }
        .btn { padding: 6px 12px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; font-size: 12px; }
        .btn-primary { background: #3498db; color: white; }
        .btn-success { background: #27ae60; color: white; }
        .btn-warning { background: #f39c12; color: white; }
        .btn-danger { background: #e74c3c; color: white; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 8px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .quick-actions { display: flex; gap: 5px; }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'sidebar.php'; ?>

        <div class="admin-content">
            <h1>إدارة المستخدمين</h1>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $total_users; ?></div>
                    <div class="stat-label">إجمالي المستخدمين</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php 
                        $active_users = array_filter($users, function($u) { return $u['status'] == 1; });
                        echo count($active_users);
                    ?></div>
                    <div class="stat-label">المستخدمين النشطين</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php 
                        $admins = array_filter($users, function($u) { return $u['role'] == 'admin'; });
                        echo count($admins);
                    ?></div>
                    <div class="stat-label">المديرين</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php 
                        $customers = array_filter($users, function($u) { return $u['role'] == 'customer'; });
                        echo count($customers);
                    ?></div>
                    <div class="stat-label">العملاء</div>
                </div>
            </div>

            <div class="users-table">
                <div class="table-header">
                    <h2>قائمة المستخدمين (<?php echo $total_users; ?> مستخدم)</h2>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>المستخدم</th>
                            <th>البريد الإلكتروني</th>
                            <th>الهاتف</th>
                            <th>الدور</th>
                            <th>الحالة</th>
                            <th>تاريخ التسجيل</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user_item): ?>
                        <tr>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div class="user-avatar">
                                        <?php echo strtoupper(substr($user_item['first_name'], 0, 1)); ?>
                                    </div>
                                    <div>
                                        <strong><?php echo $user_item['first_name'] . ' ' . $user_item['last_name']; ?></strong><br>
                                        <small>@<?php echo $user_item['username']; ?></small>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo $user_item['email']; ?></td>
                            <td><?php echo $user_item['phone'] ?: 'غير محدد'; ?></td>
                            <td>
                                <span class="role-badge role-<?php echo $user_item['role']; ?>">
                                    <?php echo $user_item['role'] == 'admin' ? 'مدير' : 'عميل'; ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo $user_item['status'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $user_item['status'] ? 'نشط' : 'غير نشط'; ?>
                                </span>
                            </td>
                            <td><?php echo date('Y-m-d', strtotime($user_item['created_at'])); ?></td>
                            <td>
                                <div class="quick-actions">
                                    <!-- تغيير الحالة -->
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="user_id" value="<?php echo $user_item['id']; ?>">
                                        <input type="hidden" name="status" value="<?php echo $user_item['status'] ? 0 : 1; ?>">
                                        <button type="submit" name="update_user_status" 
                                                class="btn <?php echo $user_item['status'] ? 'btn-warning' : 'btn-success'; ?>"
                                                onclick="return confirm('تأكيد تغيير حالة المستخدم؟')">
                                            <?php echo $user_item['status'] ? 'إيقاف' : 'تفعيل'; ?>
                                        </button>
                                    </form>
                                    
                                    <!-- تغيير الدور -->
                                    <?php if ($user_item['id'] != $_SESSION['user_id']): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="user_id" value="<?php echo $user_item['id']; ?>">
                                        <input type="hidden" name="role" value="<?php echo $user_item['role'] == 'admin' ? 'customer' : 'admin'; ?>">
                                        <button type="submit" name="update_user_role" 
                                                class="btn btn-primary"
                                                onclick="return confirm('تأكيد تغيير دور المستخدم؟')">
                                            <?php echo $user_item['role'] == 'admin' ? 'جعل عميل' : 'جعل مدير'; ?>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_users > 20): ?>
            <div class="pagination" style="display: flex; justify-content: center; gap: 10px; margin-top: 20px;">
                <?php
                $total_pages = ceil($total_users / 20);
                for ($i = 1; $i <= $total_pages; $i++):
                ?>
                    <a href="users.php?page=<?php echo $i; ?>" 
                       class="btn <?php echo $page == $i ? 'btn-success' : 'btn-primary'; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>