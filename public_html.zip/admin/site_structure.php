<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

error_log("Accessing site_structure.php, Session ID: " . session_id() . ", user_role: " . ($_SESSION['user_role'] ?? 'unset'), 3, __DIR__ . "/log.txt");

if (!isLoggedIn() || !isAdmin()) {
    error_log("Not logged in or not admin, redirecting", 3, __DIR__ . "/log.txt");
    if (isset($_GET['redirected']) && (int)$_GET['redirected'] > 3) {
        error_log("Redirect loop detected", 3, __DIR__ . "/log.txt");
        die("خطأ: حلقة توجيه مكتشفة. امسح ملفات تعريف الارتباط.");
    }
    $redirect_count = isset($_GET['redirected']) ? (int)$_GET['redirected'] + 1 : 1;
    header("Location: /admin/admin_login.php?redirected=$redirect_count");
    exit;
}

header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

if (!isset($_SESSION['logout_token'])) {
    $_SESSION['logout_token'] = bin2hex(random_bytes(32));
}

$descriptions = [
    'Uploads' => 'يخزن الملفات المرفوعة مثل صور المنتجات.',
    'products' => 'يحتوي على صور المنتجات المرفوعة.',
    '*.jpg' => 'صورة منتج.',
    '*.png' => 'صورة منتج.',
    '*.webp' => 'صورة منتج.'
];

function testPage($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
    curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [
        'status' => $http_code === 200 ? 'يعمل' : ($http_code === 404 ? 'غير موجود' : "حالة: $http_code"),
        'class' => $http_code === 200 ? 'text-success' : ($http_code === 404 ? 'text-danger' : 'text-warning'),
        'code' => $http_code
    ];
}

function scanDirectory($dir, $level = 0, $filter = '') {
    $files = [];
    $dirs = [];
    if (!is_dir($dir)) {
        error_log("Directory not found: $dir", 3, __DIR__ . "/log.txt");
        return ['files' => [], 'dirs' => []];
    }
    $handle = @opendir($dir);
    if ($handle) {
        while (($entry = readdir($handle)) !== false) {
            if ($entry === '.' || $entry === '..') continue;
            $path = $dir . '/' . $entry;
            if (is_dir($path)) {
                $dirs[] = ['name' => $entry, 'path' => $path, 'level' => $level];
            } elseif (is_file($path)) {
                if ($filter && !fnmatch($filter, $entry)) continue;
                $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
                $is_image = in_array($ext, ['jpg', 'jpeg', 'png', 'webp']);
                $test_result = $is_image ? testPage("https://doublepower.org/" . str_replace(__DIR__ . '/', '', $path)) : null;
                $files[] = [
                    'name' => $entry,
                    'path' => $path,
                    'level' => $level,
                    'size' => filesize($path),
                    'is_image' => $is_image,
                    'test_result' => $test_result
                ];
            }
        }
        closedir($handle);
    }
    usort($dirs, fn($a, $b) => strcmp($a['name'], $b['name']));
    usort($files, fn($a, $b) => strcmp($a['name'], $b['name']));
    foreach ($dirs as &$dir) {
        $sub = scanDirectory($dir['path'], $level + 1, $filter);
        $dir['subdirs'] = $sub['dirs'];
        $dir['subfiles'] = $sub['files'];
    }
    return ['files' => $files, 'dirs' => $dirs];
}

$filter = isset($_POST['filter']) ? trim($_POST['filter']) : '';
$filter_pattern = $filter ? "*.$filter" : '';
$structure = scanDirectory(__DIR__ . '/Uploads/products', 0, $filter_pattern);

function countItems($dirs, $files) {
    $total_files = count($files);
    $total_dirs = count($dirs);
    foreach ($dirs as $dir) {
        $sub_counts = countItems($dir['subdirs'], $dir['subfiles']);
        $total_files += $sub_counts['files'];
        $total_dirs += $sub_counts['dirs'];
    }
    return ['files' => $total_files, 'dirs' => $total_dirs];
}
$counts = countItems($structure['dirs'], $structure['files']);

function getDescription($name, $is_image = false) {
    global $descriptions;
    if (isset($descriptions[$name])) return $descriptions[$name];
    if ($is_image) {
        $ext = pathinfo($name, PATHINFO_EXTENSION);
        return $descriptions["*.$ext"] ?? 'ملف صورة غير معروف.';
    }
    return 'لا يوجد وصف.';
}

function displayStructure($dirs, $files) {
    $output = '';
    foreach ($dirs as $dir) {
        $indent = str_repeat('    ', $dir['level']);
        $description = getDescription($dir['name']);
        $output .= "<li class='list-group-item'>{$indent}<i class='bi bi-folder-fill text-warning me-2'></i>" . htmlspecialchars($dir['name']) . "<span class='ms-auto text-muted small'>{$description}</span></li>";
        if (!empty($dir['subdirs']) || !empty($dir['subfiles'])) {
            $output .= "<ul class='list-group list-group-flush ms-" . ($dir['level'] * 4) . "'>" . displayStructure($dir['subdirs'], $dir['subfiles']) . "</ul>";
        }
    }
    foreach ($files as $file) {
        $indent = str_repeat('    ', $file['level']);
        $icon = $file['is_image'] ? 'bi bi-image text-success' : 'bi bi-file-earmark text-primary';
        $description = getDescription($file['name'], $file['is_image']);
        $output .= "<li class='list-group-item'>{$indent}<i class='{$icon} me-2'></i>" . htmlspecialchars($file['name']) . "<span class='ms-auto text-muted small'>{$description}</span>";
        if ($file['is_image']) {
            $output .= "<span class='{$file['test_result']['class']} me-2'>{$file['test_result']['status']}</span>";
            $output .= "<a href='https://doublepower.org/" . str_replace(__DIR__ . '/', '', $file['path']) . "' target='_blank' class='btn btn-sm btn-outline-primary'>زيارة</a>";
        }
        $output .= "</li>";
    }
    return $output;
}

function formatSize($bytes) {
    if ($bytes >= 1024 * 1024) return number_format($bytes / (1024 * 1024), 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

function generateWordFile($dirs, $files, $counts) {
    $content = "هيكلية صور المنتجات\nإجمالي المجلدات: {$counts['dirs']}\nإجمالي الملفات: {$counts['files']}\nتاريخ التقرير: " . date('Y-m-d H:i:s') . "\n\n";
    function addStructureToText($dirs, $files, &$content) {
        foreach ($dirs as $dir) {
            $indent = str_repeat('  ', $dir['level']);
            $description = getDescription($dir['name']);
            $content .= "{$indent}📁 {$dir['name']} - {$description}\n";
            addStructureToText($dir['subdirs'], $dir['subfiles'], $content);
        }
        foreach ($files as $file) {
            $indent = str_repeat('  ', $file['level']);
            $description = getDescription($file['name'], $file['is_image']);
            $content .= "{$indent}📄 {$file['name']} (" . formatSize($file['size']) . ") - {$description}";
            if ($file['is_image']) {
                $content .= " - الحالة: {$file['test_result']['status']}";
            }
            $content .= "\n";
        }
    }
    addStructureToText($dirs, $files, $content);
    $filename = 'products_images_' . date('Ymd_His') . '.doc';
    header('Content-Type: application/msword');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo $content;
    exit;
}

if (isset($_POST['download_word'])) {
    generateWordFile($structure['dirs'], $structure['files'], $counts);
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>هيكلية صور المنتجات</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .list-group-item { border-radius: 0; }
        .filter-form { max-width: 300px; }
        .stats { font-size: 0.9rem; }
        .text-success { color: #28a745 !important; }
        .text-danger { color: #dc3545 !important; }
        .text-warning { color: #ffc107 !important; }
        .description { max-width: 300px; text-overflow: ellipsis; overflow: hidden; white-space: nowrap; }
        body { background-color: #f0f0f0; }
    </style>
</head>
<body>
<div class="container py-5">
    <h2 class="mb-4">هيكلية صور المنتجات</h2>
    <div class="alert alert-info">تحديث: 18 يونيو 2025</div>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="mb-0">الملفات والمجلدات</h4>
            <div>
                <form class="filter-form d-flex d-inline-block me-2" method="post">
                    <select name="filter" class="form-select me-2" onchange="this.form.submit()">
                        <option value="">جميع الملفات</option>
                        <option value="jpg" <?= $filter === 'jpg' ? 'selected' : '' ?>>JPG</option>
                        <option value="png" <?= $filter === 'png' ? 'selected' : '' ?>>PNG</option>
                       ­mains/doublepower.org/public_html/Uploads/products/
     chmod -R 775 /home/u647818269/domains/doublepower.org/public_html/Uploads/products/
     chown -R nobody:nobody /home/u647818269/domains/doublepower.org/public_html/Uploads/products/
     ```
   - للاختبار، أضف صورة:
     ```bash
     cp /path/to/sample.jpg /home/u647818269/domains/doublepower.org/public_html/Uploads/products/test.jpg
     ```

4. **فحص `.htaccess`**:
   ```bash
   cat /home/u647818269/domains/doublepower.org/public_html/.htaccess
   ```
   - إذا وجد، أعد تسميته:
     ```bash
     mv /home/u647818269/domains/doublepower.org/public_html/.htaccess /home/u647818269/public_html/.htaccess.bak
     ```

5. **فحص مسار الجلسة**:
   ```bash
   php -i | grep session.save_path
   ```
   - تأكد من أنه قابل للكتابة:
     ```bash
     chmod -R 775 /path/to/session/save
     ```

6. **اختبار الموقع**:
   - افتح:
     ```
     https://doublepower.org/site_structure.php
     ```
   - إذا تم التوجيه إلى `/admin/admin_login.php`, سجل الدخول ببيانات المشرف.
   - اختر `jpg` في `site_structure.php` وتحقق من ظهور الصور.

7. **جمع البيانات**:
   - نفّذ:
     ```bash
     tail -n 50 /home/u647818269/log.txt
     ```
   - شارك:
     - `DESCRIBE users; SELECT id, username, role FROM users WHERE role = 'admin';`
     - `ls -l /home/u647818269/domains/doublepower.org/public_html/Uploads/products/`
     - محتوى `.htaccess` (إذا وجد).
     - نتائج الاختبار (هل نجح تسجيل الدخول؟ هل ظهرت الصور؟).

8. **نسخ احتياطي**:
   ```bash
   tar -czf /home/u647818269/backup_$(date +%F_%H-%M).tar.gz /home/u647818269/domains/doublepower.org/public_html/
   ```

---

### **روابط الأكواد**

- **`config.php`**: [xaiArtifact://1e7272b7-4d65-420f-ab20-b4d4bd36575e/a1b2c3d4-5678-9012-3456-7890abcdef12]
- **`auth.php`**: [xaiArtifact://14189c84-bab8-4781-9033-750630069b1a/b2c3d4e5-6789-0123-4567-8901bcdef234]
- **`admin_login.php`**: [xaiArtifact://63faa40a-6cdc-44a8-be9f-15a40c25835b/c3d4e5f6-7890-1234-5678-9012cdef3456]
- **`site_structure.php`**: [xaiArtifact://a55c6637-8c6f-46fd-9067-9a9787255537/d4e5f6g7-8901-2345-6789-0123def45678]
- **`admin_logout.php`**: [xaiArtifact://2f2a1eb6-fef0-4774-9870-9a9ddeb2fb96/e5f6g7h8-9012-3456-7890-1234ef567890]

---

### **ملاحظات**
- الأكواد تعتمد على `role` في `users` مع قيم `admin` و`customer`.
- إذا استمرت المشكلة, شارك النتائج لتشخيص دقيق.
- الوقت: **05:35 صباحًا، الأربعاء، 18 يونيو 2025**.