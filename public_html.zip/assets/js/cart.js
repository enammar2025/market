document.querySelectorAll('.add-to-cart').forEach(btn => {
  btn.onclick = function() {
    const productId = this.dataset.id;
    fetch(`/cart_add.php?id=${productId}`, { method: 'POST' })
      .then(res => res.json())
      .then(data => {
        document.getElementById('cart-count').textContent = data.count;
        // يمكنك عرض رسالة أو نافذة جانبية هنا
      });
  };
});