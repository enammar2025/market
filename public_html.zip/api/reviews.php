<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;

if ($method === 'GET' && $product_id) {
    // جلب تقييمات المنتج
    $query = "SELECT r.*, u.first_name, u.last_name 
              FROM reviews r 
              LEFT JOIN users u ON r.user_id = u.id 
              WHERE r.product_id = ? AND r.status = 1 
              ORDER BY r.created_at DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute([$product_id]);
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // حساب متوسط التقييم
    $avg_query = "SELECT AVG(rating) as avg_rating, COUNT(*) as total_reviews 
                  FROM reviews WHERE product_id = ? AND status = 1";
    $avg_stmt = $db->prepare($avg_query);
    $avg_stmt->execute([$product_id]);
    $avg_data = $avg_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'reviews' => $reviews,
        'average_rating' => round($avg_data['avg_rating'], 1),
        'total_reviews' => $avg_data['total_reviews']
    ], JSON_UNESCAPED_UNICODE);
    
} elseif ($method === 'POST') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'يجب تسجيل الدخول أولاً']);
        exit;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $product_id = $input['product_id'];
    $rating = $input['rating'];
    $comment = $input['comment'];
    $user_id = $_SESSION['user_id'];
    
    // التحقق من عدم وجود تقييم سابق
    $check_query = "SELECT id FROM reviews WHERE product_id = ? AND user_id = ?";
    $check_stmt = $db->prepare($check_query);
    $check_stmt->execute([$product_id, $user_id]);
    
    if ($check_stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'لقد قمت بتقييم هذا المنتج مسبقاً']);
        exit;
    }
    
    // إضافة التقييم
    $insert_query = "INSERT INTO reviews (product_id, user_id, rating, comment, status) 
                     VALUES (?, ?, ?, ?, 0)";
    $insert_stmt = $db->prepare($insert_query);
    
    if ($insert_stmt->execute([$product_id, $user_id, $rating, $comment])) {
        echo json_encode(['success' => true, 'message' => 'تم إضافة تقييمك وسيتم مراجعته']);
    } else {
        echo json_encode(['success' => false, 'message' => 'حدث خطأ في إضافة التقييم']);
    }
}
?>