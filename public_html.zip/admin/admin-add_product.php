<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/config.php';

if (!isAdmin()) {
    header('Location: /admin/admin_login.php');
    exit;
}

// توليد رمز CSRF
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// جلب الفئات
try {
    $stmt = $pdo->query("SELECT id, name FROM categories WHERE status = 1 ORDER BY name");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("خطأ في جلب الفئات: " . $e->getMessage(), 3, __DIR__ . "/../log.txt");
    $_SESSION['error_message'] = "حدث خطأ في جلب الفئات.";
}

// جلب المنتجات مع البحث
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$products = [];
try {
    $query = "SELECT p.id, p.name, p.price, p.sku, p.stock_quantity, p.status, p.image, c.name AS category_name 
              FROM products p 
              LEFT JOIN categories c ON p.category_id = c.id";
    if ($search) {
        $query .= " WHERE p.name LIKE :search OR p.sku LIKE :search";
    }
    $query .= " ORDER BY p.created_at DESC";
    $stmt = $pdo->prepare($query);
    if ($search) {
        $stmt->execute(['search' => "%$search%"]);
    } else {
        $stmt->execute();
    }
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("خطأ في جلب المنتجات: " . $e->getMessage(), 3, __DIR__ . "/../log.txt");
    $_SESSION['error_message'] = "حدث خطأ في جلب المنتجات.";
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المنتجات - DoublePower</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        .upload-area { border: 2px dashed #dee2e6; padding: 2rem; text-align: center; }
        .image-preview { max-height: 100px; margin: 5px; object-fit: contain; }
        .card { border-radius: 12px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); }
        .required-field::after { content: " *"; color: #dc3545; }
        .form-control.is-invalid, .form-select.is-invalid { border-color: #dc3545; }
        .table-responsive { margin-top: 2rem; }
        .product-image { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; }
        .btn-sm { padding: 0.25rem 0.5rem; }
        .card-header { background: linear-gradient(90deg, #007bff, #0056b3); }
    </style>
</head>
<body>
<?php include __DIR__ . '/../includes/admin_header.php'; ?>

<div class="container py-5">
    <!-- نموذج إضافة المنتج -->
    <div class="card shadow-sm mb-5">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-cube me-2"></i>إضافة منتج جديد</h4>
        </div>
        <div class="card-body">
            <?php include __DIR__ . '/../includes/alerts.php'; ?>
            <form id="productForm" action="/admin/process_product.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

                <div class="row g-4">
                    <!-- المعلومات الأساسية -->
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="name" class="form-label required-field">اسم المنتج</label>
                            <input type="text" class="form-control" id="name" name="name" required maxlength="100">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">الوصف</label>
                            <textarea class="form-control" id="description" name="description" rows="5" maxlength="2000"></textarea>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="price" class="form-label required-field">السعر (ر.س)</label>
                                <input type="number" step="0.01" min="0" class="form-control" id="price" name="price" required>
                            </div>
                            <div class="col-md-6">
                                <label for="compare_price" class="form-label">السعر قبل الخصم</label>
                                <input type="number" step="0.01" min="0" class="form-control" id="compare_price" name="compare_price">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="sku" class="form-label required-field">رمز SKU</label>
                            <input type="text" class="form-control" id="sku" name="sku" required maxlength="50">
                        </div>
                        <div class="mb-3">
                            <label for="stock_quantity" class="form-label required-field">كمية المخزون</label>
                            <input type="number" min="0" class="form-control" id="stock_quantity" name="stock_quantity" required>
                        </div>
                    </div>

                    <!-- الصور والفئات -->
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label required-field">صور المنتج (الحد الأقصى 5MB)</label>
                            <div class="upload-area">
                                <i class="fas fa-cloud-upload-alt fa-2x text-muted mb-3"></i>
                                <p>انقر لاختيار الصور (JPG, PNG, WEBP)</p>
                                <input type="file" id="imageInput" name="images[]" accept="image/jpeg,image/png,image/webp" multiple>
                            </div>
                            <div id="imagePreviews" class="d-flex flex-wrap mt-2"></div>
                            <div id="imageError" class="invalid-feedback d-block"></div>
                        </div>
                        <div class="mb-3">
                            <label for="category_id" class="form-label required-field">الفئة</label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="" disabled selected>اختر الفئة...</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= htmlspecialchars($category['id']) ?>"><?= htmlspecialchars($category['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="status" class="form-label required-field">حالة المنتج</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="1" selected>نشط</option>
                                <option value="0">غير نشط</option>
                            </select>
                        </div>
                    </div>

                    <!-- الخصومات -->
                    <div class="col-12">
                        <h5 class="mb-3"><i class="fas fa-tags me-2"></i>الخصومات</h5>
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label for="discount_type" class="form-label">نوع الخصم</label>
                                <select class="form-select" id="discount_type" name="discount_type">
                                    <option value="">لا خصم</option>
                                    <option value="percentage">نسبة مئوية</option>
                                    <option value="fixed">مبلغ ثابت</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="discount_value" class="form-label">قيمة الخصم</label>
                                <input type="number" step="0.01" min="0" class="form-control" id="discount_value" name="discount_value">
                            </div>
                            <div class="col-md-3">
                                <label for="discount_start" class="form-label">تاريخ البدء</label>
                                <input type="datetime-local" class="form-control" id="discount_start" name="discount_start">
                            </div>
                            <div class="col-md-3">
                                <label for="discount_end" class="form-label">تاريخ الانتهاء</label>
                                <input type="datetime-local" class="form-control" id="discount_end" name="discount_end">
                            </div>
                        </div>
                    </div>

                    <!-- المواصفات -->
                    <div class="col-12">
                        <h5 class="mb-3"><i class="fas fa-list-ul me-2"></i>مواصفات المنتج</h5>
                        <div id="specificationsContainer">
                            <div class="row g-3 mb-3 specification-row">
                                <div class="col-md-5">
                                    <input type="text" class="form-control" name="specs[0][key]" placeholder="اسم المواصفة">
                                </div>
                                <div class="col-md-5">
                                    <input type="text" class="form-control" name="specs[0][value]" placeholder="القيمة">
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-outline-danger remove-spec" disabled>حذف</button>
                                </div>
                            </div>
                        </div>
                        <button type="button" id="addSpecBtn" class="btn btn-outline-primary mt-2">
                            <i class="fas fa-plus me-1"></i> إضافة مواصفة
                        </button>
                    </div>
                </div>

                <div class="d-flex justify-content-between mt-5">
                    <div>
                        <a href="/index.php" class="btn btn-outline-primary me-2"><i class="fas fa-home me-1"></i> العودة إلى الصفحة الرئيسية</a>
                        <a href="/admin/logout.php" class="btn btn-outline-danger"><i class="fas fa-sign-out-alt me-1"></i> تسجيل الخروج</a>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i> حفظ المنتج</button>
                </div>
            </form>
        </div>
    </div>

    <!-- قسم استعراض المنتجات -->
    <div class="card shadow-sm">
        <div class="card-header bg-secondary text-white">
            <h4 class="mb-0"><i class="fas fa-list me-2"></i>استعراض المنتجات</h4>
        </div>
        <div class="card-body">
            <form class="mb-4" method="get" action="/admin-add_product.php">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="ابحث بالاسم أو SKU" value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search me-1"></i> بحث</button>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>صورة</th>
                            <th>اسم المنتج</th>
                            <th>السعر (ر.س)</th>
                            <th>SKU</th>
                            <th>الفئة</th>
                            <th>الكمية</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($products)): ?>
                            <tr><td colspan="8" class="text-center">لا توجد منتجات.</td></tr>
                        <?php else: ?>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td><img src="/<?= htmlspecialchars($product['image']) ?>" class="product-image" alt="صورة المنتج"></td>
                                    <td><?= htmlspecialchars($product['name']) ?></td>
                                    <td><?= number_format($product['price'], 2) ?></td>
                                    <td><?= htmlspecialchars($product['sku']) ?></td>
                                    <td><?= htmlspecialchars($product['category_name'] ?: 'غير مصنف') ?></td>
                                    <td><?= $product['stock_quantity'] ?></td>
                                    <td>
                                        <span class="badge bg-<?= $product['status'] ? 'success' : 'secondary' ?>">
                                            <?= $product['status'] ? 'نشط' : 'غير نشط' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="/admin/edit_product.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-outline-primary me-1" title="تعديل">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteModal" data-id="<?= $product['id'] ?>" data-name="<?= htmlspecialchars($product['name']) ?>" title="حذف">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- نافذة تأكيد الحذف -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">تأكيد الحذف</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                هل أنت متأكد من حذف المنتج: <strong id="deleteProductName"></strong>؟
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <a id="confirmDeleteBtn" href="#" class="btn btn-danger">حذف</a>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('JavaScript loaded for admin-add_product.php');

    const maxSize = 5 * 1024 * 1024; // 5MB
    let specCounter = 1;
    const imageInput = document.getElementById('imageInput');
    const imagePreviews = document.getElementById('imagePreviews');
    const imageError = document.getElementById('imageError');

    // التحقق من وجود العناصر
    if (!imageInput || !imagePreviews || !imageError) {
        console.error('Missing DOM elements:', { imageInput, imagePreviews, imageError });
        imageError.textContent = 'خطأ في تحميل واجهة رفع الصور';
        imageError.classList.remove('d-none');
        return;
    }

    // معالجة اختيار الصور
    imageInput.addEventListener('change', function() {
        console.log('File input changed:', this.files.length, 'files');
        handleImages(this.files);
    });

    function handleImages(files) {
        imagePreviews.innerHTML = '';
        imageError.textContent = '';
        imageError.classList.add('d-none');
        const validTypes = ['image/jpeg', 'image/png', 'image/webp'];

        Array.from(files).forEach(file => {
            console.log('Processing:', file.name, file.type, file.size);
            if (!validTypes.includes(file.type)) {
                console.warn('Invalid type:', file.type);
                imageError.textContent = 'نوع الملف غير مدعوم: ' + file.name;
                imageError.classList.remove('d-none');
                return;
            }
            if (file.size > maxSize) {
                console.warn('File too large:', file.size);
                imageError.textContent = 'حجم الصورة كبير جدًا: ' + file.name;
                imageError.classList.remove('d-none');
                return;
            }
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.className = 'image-preview img-thumbnail';
                img.alt = 'معاينة الصورة';
                imagePreviews.appendChild(img);
                console.log('Preview added:', file.name);
            };
            reader.onerror = function() {
                console.error('FileReader error:', file.name);
                imageError.textContent = 'خطأ في قراءة الصورة: ' + file.name;
                imageError.classList.remove('d-none');
            };
            reader.readAsDataURL(file);
        });
    }

    // إضافة مواصفة
    document.getElementById('addSpecBtn').addEventListener('click', function() {
        const container = document.getElementById('specificationsContainer');
        const row = document.createElement('div');
        row.className = 'row g-3 mb-3 specification-row';
        row.innerHTML = `
            <div class="col-md-5">
                <input type="text" class="form-control" name="specs[${specCounter}][key]" placeholder="اسم المواصفة">
            </div>
            <div class="col-md-5">
                <input type="text" class="form-control" name="specs[${specCounter}][value]" placeholder="القيمة">
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-outline-danger remove-spec">حذف</button>
            </div>
        `;
        container.appendChild(row);
        specCounter++;
        document.querySelectorAll('.remove-spec').forEach(btn => btn.disabled = false);
        console.log('Specification added:', specCounter);
    });

    // حذف مواصفة
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-spec')) {
            const row = e.target.closest('.specification-row');
            if (row && document.querySelectorAll('.specification-row').length > 1) {
                row.remove();
                console.log('Specification removed');
            }
            if (document.querySelectorAll('.specification-row').length === 1) {
                document.querySelector('.remove-spec').disabled = true;
            }
        }
    });

    // التحقق من النموذج
    document.getElementById('productForm').addEventListener('submit', function(e) {
        let isValid = true;
        imageError.textContent = '';
        imageError.classList.add('d-none');

        document.querySelectorAll('[required]').forEach(field => {
            if (!field.value.trim()) {
                field.classList.add('is-invalid');
                isValid = false;
            } else {
                field.classList.remove('is-invalid');
            }
        });

        if (!imageInput.files.length) {
            imageError.textContent = 'يجب اختيار صورة واحدة على الأقل';
            imageError.classList.remove('d-none');
            isValid = false;
        }

        if (!isValid) {
            e.preventDefault();
            const firstInvalid = document.querySelector('.is-invalid') || imageError;
            firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
            console.log('Form validation failed');
        } else {
            console.log('Form validated, submitting');
        }
    });

    // إعداد نافذة الحذف
    const deleteModal = document.getElementById('deleteModal');
    deleteModal.addEventListener('show.bs.modal', function(event) {
        const button = event.relatedTarget;
        const productId = button.getAttribute('data-id');
        const productName = button.getAttribute('data-name');
        const confirmBtn = document.getElementById('confirmDeleteBtn');
        const productNameEl = document.getElementById('deleteProductName');
        productNameEl.textContent = productName;
        confirmBtn.setAttribute('href', '/admin/delete_product.php?id=' + productId);
    });
});
</script>
</body>
</html>