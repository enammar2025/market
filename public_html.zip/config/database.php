<?php
class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $port;
    public $conn;

    public function __construct() {
        // إعدادات قاعدة البيانات على هوستنغر - يجب تعديلها
        $this->host = 'localhost';
        $this->db_name = 'u647818269_PowerMarket'; // مثال: u123456789_powermarket
        $this->username = 'u647818269_enammar2025'; // مثال: u123456789_dbuser
        $this->password = '#Hind@Osama2020!'; // كلمة المرور الخاصة بك
        define('DB_CHARSET', 'utf8mb4');
        $this->port = '3306';
    }

    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8mb4");
        } catch(PDOException $exception) {
            echo "خطأ في الاتصال: " . $exception->getMessage();
        }

        return $this->conn;
    }

    public function initializeTables() {
        // الجداول موجودة بالفعل في قاعدة البيانات المستوردة
        // لا نحتاج لإنشائها مرة أخرى
        return true;
    }
}
?>
