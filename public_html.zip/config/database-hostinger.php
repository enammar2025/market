<?php
class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $port;
    public $conn;

    public function __construct() {
        // إعدادات قاعدة البيانات على هوستنغر
        $this->host = 'localhost'; // أو عنوان قاعدة البيانات من هوستنغر
        $this->db_name = 'u123456789_powermarket'; // اسم قاعدة البيانات
        $this->username = 'u123456789_dbuser'; // اسم المستخدم
        $this->password = 'YOUR_PASSWORD_HERE'; // كلمة المرور
        $this->port = '3306';
    }

    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8mb4");
        } catch(PDOException $exception) {
            echo "خطأ في الاتصال: " . $exception->getMessage();
        }

        return $this->conn;
    }

    public function initializeTables() {
        // الجداول ستُنشأ من ملف SQL المستورد
        return true;
    }
}
?>