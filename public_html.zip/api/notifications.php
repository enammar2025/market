<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit;
}

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$notifications = [];

// فحص المنتجات قليلة المخزون
$low_stock_query = "SELECT name, stock_quantity FROM products 
                    WHERE stock_quantity < 5 AND status = 1";
$stmt = $db->prepare($low_stock_query);
$stmt->execute();
$low_stock_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($low_stock_items as $item) {
    $notifications[] = [
        'type' => 'warning',
        'title' => 'مخزون منخفض',
        'message' => "المنتج '{$item['name']}' متبقي منه {$item['stock_quantity']} قطع فقط",
        'time' => date('Y-m-d H:i:s'),
        'priority' => 'high'
    ];
}

// فحص الطلبات المعلقة
$pending_orders_query = "SELECT COUNT(*) as count FROM orders WHERE status = 'pending'";
$stmt = $db->prepare($pending_orders_query);
$stmt->execute();
$pending_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

if ($pending_count > 0) {
    $notifications[] = [
        'type' => 'info',
        'title' => 'طلبات معلقة',
        'message' => "يوجد {$pending_count} طلب في انتظار المراجعة",
        'time' => date('Y-m-d H:i:s'),
        'priority' => 'medium'
    ];
}

// فحص التقييمات المعلقة
$pending_reviews_query = "SELECT COUNT(*) as count FROM reviews WHERE status = 0";
$stmt = $db->prepare($pending_reviews_query);
$stmt->execute();
$reviews_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

if ($reviews_count > 0) {
    $notifications[] = [
        'type' => 'info',
        'title' => 'تقييمات تحتاج مراجعة',
        'message' => "يوجد {$reviews_count} تقييم في انتظار الموافقة",
        'time' => date('Y-m-d H:i:s'),
        'priority' => 'low'
    ];
}

// فحص المبيعات اليوم
$today_sales_query = "SELECT COUNT(*) as orders, SUM(total) as revenue 
                      FROM orders WHERE DATE(created_at) = CURDATE()";
$stmt = $db->prepare($today_sales_query);
$stmt->execute();
$today_data = $stmt->fetch(PDO::FETCH_ASSOC);

if ($today_data['orders'] > 0) {
    $notifications[] = [
        'type' => 'success',
        'title' => 'مبيعات اليوم',
        'message' => "تم بيع {$today_data['orders']} طلب بإجمالي " . number_format($today_data['revenue'], 2) . " ر.س",
        'time' => date('Y-m-d H:i:s'),
        'priority' => 'low'
    ];
}

echo json_encode([
    'success' => true,
    'notifications' => $notifications,
    'count' => count($notifications)
], JSON_UNESCAPED_UNICODE);
?>