<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

$message = '';
$message_type = '';

// معالجة حفظ الإعدادات
if ($_POST && isset($_POST['save_settings'])) {
    $settings = [
        'site_name' => $_POST['site_name'],
        'site_email' => $_POST['site_email'],
        'site_phone' => $_POST['site_phone'],
        'site_address' => $_POST['site_address'],
        'currency' => $_POST['currency'],
        'tax_rate' => $_POST['tax_rate'],
        'shipping_fee' => $_POST['shipping_fee'],
        'items_per_page' => $_POST['items_per_page'],
        'maintenance_mode' => isset($_POST['maintenance_mode']) ? 1 : 0,
        'allow_registration' => isset($_POST['allow_registration']) ? 1 : 0
    ];
    
    $success = true;
    foreach ($settings as $key => $value) {
        $query = "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) 
                  ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
        $stmt = $db->prepare($query);
        if (!$stmt->execute([$key, $value])) {
            $success = false;
            break;
        }
    }
    
    if ($success) {
        $message = 'تم حفظ الإعدادات بنجاح';
        $message_type = 'success';
    } else {
        $message = 'حدث خطأ في حفظ الإعدادات';
        $message_type = 'error';
    }
}

// جلب الإعدادات الحالية
$current_settings = [];
$query = "SELECT setting_key, setting_value FROM settings";
$stmt = $db->prepare($query);
$stmt->execute();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $current_settings[$row['setting_key']] = $row['setting_value'];
}

// قيم افتراضية
$defaults = [
    'site_name' => 'متجر الطاقة الكهربائية',
    'site_email' => 'info@powermarket.com',
    'site_phone' => '+966-XX-XXXX-XXXX',
    'site_address' => 'الرياض، المملكة العربية السعودية',
    'currency' => 'ر.س',
    'tax_rate' => '15',
    'shipping_fee' => '25.00',
    'items_per_page' => '12',
    'maintenance_mode' => '0',
    'allow_registration' => '1'
];

foreach ($defaults as $key => $value) {
    if (!isset($current_settings[$key])) {
        $current_settings[$key] = $value;
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إعدادات المتجر - متجر الطاقة الكهربائية</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .admin-container { display: flex; min-height: 100vh; background: #f8f9fa; }
        .admin-content { margin-right: 280px; padding: 30px; width: calc(100% - 280px); }
        .settings-tabs { display: flex; background: white; border-radius: 10px; margin-bottom: 20px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .settings-tab { flex: 1; padding: 20px; text-align: center; cursor: pointer; border-bottom: 3px solid transparent; transition: all 0.3s; }
        .settings-tab.active { border-bottom-color: #3498db; background: #f8f9fa; }
        .tab-content { display: none; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .tab-content.active { display: block; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: bold; color: #333; }
        .form-group input, .form-group textarea, .form-group select { width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 8px; font-size: 16px; }
        .form-group textarea { height: 100px; resize: vertical; }
        .checkbox-group { display: flex; align-items: center; gap: 10px; }
        .checkbox-group input[type="checkbox"] { width: auto; }
        .btn { padding: 12px 24px; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; transition: all 0.3s; }
        .btn-primary { background: #3498db; color: white; }
        .btn-success { background: #27ae60; color: white; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 8px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .info-card { background: #e8f4fd; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .backup-section { background: #fff3cd; padding: 20px; border-radius: 8px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'sidebar.php'; ?>

        <div class="admin-content">
            <h1>إعدادات المتجر</h1>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="settings-tabs">
                <div class="settings-tab active" data-tab="general">الإعدادات العامة</div>
                <div class="settings-tab" data-tab="payment">إعدادات الدفع</div>
                <div class="settings-tab" data-tab="system">إعدادات النظام</div>
                <div class="settings-tab" data-tab="backup">النسخ الاحتياطي</div>
            </div>

            <form method="POST">
                <!-- الإعدادات العامة -->
                <div class="tab-content active" id="general-tab">
                    <h2>معلومات المتجر الأساسية</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="site_name">اسم المتجر</label>
                            <input type="text" id="site_name" name="site_name" 
                                   value="<?php echo $current_settings['site_name']; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="site_email">البريد الإلكتروني</label>
                            <input type="email" id="site_email" name="site_email" 
                                   value="<?php echo $current_settings['site_email']; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="site_phone">رقم الهاتف</label>
                            <input type="tel" id="site_phone" name="site_phone" 
                                   value="<?php echo $current_settings['site_phone']; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="currency">العملة</label>
                            <select id="currency" name="currency">
                                <option value="ر.س" <?php echo $current_settings['currency'] == 'ر.س' ? 'selected' : ''; ?>>ريال سعودي (ر.س)</option>
                                <option value="$" <?php echo $current_settings['currency'] == '$' ? 'selected' : ''; ?>>دولار أمريكي ($)</option>
                                <option value="€" <?php echo $current_settings['currency'] == '€' ? 'selected' : ''; ?>>يورو (€)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="site_address">عنوان المتجر</label>
                        <textarea id="site_address" name="site_address"><?php echo $current_settings['site_address']; ?></textarea>
                    </div>
                </div>

                <!-- إعدادات الدفع -->
                <div class="tab-content" id="payment-tab">
                    <h2>إعدادات الدفع والشحن</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="tax_rate">نسبة الضريبة (%)</label>
                            <input type="number" step="0.01" id="tax_rate" name="tax_rate" 
                                   value="<?php echo $current_settings['tax_rate']; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="shipping_fee">رسوم الشحن الثابتة</label>
                            <input type="number" step="0.01" id="shipping_fee" name="shipping_fee" 
                                   value="<?php echo $current_settings['shipping_fee']; ?>" required>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <h4>معلومات مهمة:</h4>
                        <ul>
                            <li>نسبة الضريبة في السعودية: 15%</li>
                            <li>رسوم الشحن يمكن تعديلها لاحقاً حسب المنطقة</li>
                            <li>سيتم تطبيق هذه الإعدادات على جميع الطلبات الجديدة</li>
                        </ul>
                    </div>
                </div>

                <!-- إعدادات النظام -->
                <div class="tab-content" id="system-tab">
                    <h2>إعدادات النظام</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="items_per_page">عدد المنتجات في الصفحة</label>
                            <select id="items_per_page" name="items_per_page">
                                <option value="8" <?php echo $current_settings['items_per_page'] == '8' ? 'selected' : ''; ?>>8 منتجات</option>
                                <option value="12" <?php echo $current_settings['items_per_page'] == '12' ? 'selected' : ''; ?>>12 منتج</option>
                                <option value="16" <?php echo $current_settings['items_per_page'] == '16' ? 'selected' : ''; ?>>16 منتج</option>
                                <option value="24" <?php echo $current_settings['items_per_page'] == '24' ? 'selected' : ''; ?>>24 منتج</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="maintenance_mode" name="maintenance_mode" 
                                   <?php echo $current_settings['maintenance_mode'] ? 'checked' : ''; ?>>
                            <label for="maintenance_mode">وضع الصيانة (إيقاف المتجر مؤقتاً)</label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="allow_registration" name="allow_registration" 
                                   <?php echo $current_settings['allow_registration'] ? 'checked' : ''; ?>>
                            <label for="allow_registration">السماح بتسجيل عملاء جدد</label>
                        </div>
                    </div>
                </div>

                <!-- النسخ الاحتياطي -->
                <div class="tab-content" id="backup-tab">
                    <h2>النسخ الاحتياطي والأمان</h2>
                    
                    <div class="backup-section">
                        <h3>النسخ الاحتياطي التلقائي</h3>
                        <p>يتم إنشاء نسخة احتياطية تلقائياً كل يوم في الساعة 2:00 صباحاً</p>
                        <button type="button" class="btn btn-primary" onclick="createBackup()">
                            <i class="fas fa-download"></i> إنشاء نسخة احتياطية الآن
                        </button>
                    </div>
                    
                    <div class="info-card">
                        <h4>معلومات الأمان:</h4>
                        <ul>
                            <li>يتم تشفير جميع كلمات المرور</li>
                            <li>النسخ الاحتياطية تحفظ في مكان آمن</li>
                            <li>يتم مراقبة النشاطات المشبوهة</li>
                            <li>آخر نسخة احتياطية: <?php echo date('Y-m-d H:i'); ?></li>
                        </ul>
                    </div>
                </div>

                <div style="margin-top: 30px; text-align: center;">
                    <button type="submit" name="save_settings" class="btn btn-success">
                        <i class="fas fa-save"></i> حفظ جميع الإعدادات
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // إدارة التبويبات
        document.querySelectorAll('.settings-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                const tabName = this.dataset.tab;
                
                // إزالة التفعيل من جميع التبويبات
                document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                // تفعيل التبويب المختار
                this.classList.add('active');
                document.getElementById(tabName + '-tab').classList.add('active');
            });
        });

        // إنشاء نسخة احتياطية
        function createBackup() {
            if (confirm('هل تريد إنشاء نسخة احتياطية الآن؟')) {
                // هنا يمكن إضافة كود AJAX لإنشاء النسخة الاحتياطية
                alert('تم إنشاء النسخة الاحتياطية بنجاح');
            }
        }

        // تحذير وضع الصيانة
        document.getElementById('maintenance_mode').addEventListener('change', function() {
            if (this.checked) {
                alert('تحذير: تفعيل وضع الصيانة سيمنع العملاء من الوصول للمتجر');
            }
        });
    </script>
</body>
</html>