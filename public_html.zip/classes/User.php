<?php
class User {
    private $conn;
    private $table_name = "users";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function register($username, $email, $password, $first_name, $last_name, $phone = '', $address = '') {
        $query = "INSERT INTO " . $this->table_name . " 
                  (username, email, password, first_name, last_name, phone, address, role, status) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, 'customer', 1)";
        
        $stmt = $this->conn->prepare($query);
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        
        $stmt->bindParam(1, $username);
        $stmt->bindParam(2, $email);
        $stmt->bindParam(3, $password_hash);
        $stmt->bindParam(4, $first_name);
        $stmt->bindParam(5, $last_name);
        $stmt->bindParam(6, $phone);
        $stmt->bindParam(7, $address);
        
        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function login($email, $password) {
        $query = "SELECT id, username, email, password, first_name, last_name, phone, role, status 
                  FROM " . $this->table_name . " 
                  WHERE email = ? AND status = 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $email);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($password, $row['password'])) {
                return $row;
            }
        }
        return false;
    }

    public function emailExists($email) {
        $query = "SELECT id FROM " . $this->table_name . " WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $email);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }

    public function usernameExists($username) {
        $query = "SELECT id FROM " . $this->table_name . " WHERE username = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $username);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }

    public function getUserById($id) {
        $query = "SELECT id, username, email, first_name, last_name, phone, address, role, status, created_at 
                  FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    public function updateProfile($id, $first_name, $last_name, $phone, $address) {
        $query = "UPDATE " . $this->table_name . " 
                  SET first_name = ?, last_name = ?, phone = ?, address = ?, updated_at = CURRENT_TIMESTAMP 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $first_name);
        $stmt->bindParam(2, $last_name);
        $stmt->bindParam(3, $phone);
        $stmt->bindParam(4, $address);
        $stmt->bindParam(5, $id);
        
        return $stmt->execute();
    }

    public function changePassword($id, $current_password, $new_password) {
        // First verify current password
        $query = "SELECT password FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($current_password, $row['password'])) {
                // Update password
                $update_query = "UPDATE " . $this->table_name . " 
                                SET password = ?, updated_at = CURRENT_TIMESTAMP 
                                WHERE id = ?";
                $update_stmt = $this->conn->prepare($update_query);
                $password_hash = password_hash($new_password, PASSWORD_BCRYPT);
                $update_stmt->bindParam(1, $password_hash);
                $update_stmt->bindParam(2, $id);
                
                return $update_stmt->execute();
            }
        }
        return false;
    }

    public function getAllUsers($page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        
        $query = "SELECT id, username, email, first_name, last_name, phone, role, status, created_at 
                  FROM " . $this->table_name . " 
                  ORDER BY created_at DESC 
                  LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $limit, PDO::PARAM_INT);
        $stmt->bindParam(2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTotalUsers() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }

    public function updateUserStatus($id, $status) {
        $query = "UPDATE " . $this->table_name . " 
                  SET status = ?, updated_at = CURRENT_TIMESTAMP 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $status);
        $stmt->bindParam(2, $id);
        
        return $stmt->execute();
    }

    public function updateUserRole($id, $role) {
        $query = "UPDATE " . $this->table_name . " 
                  SET role = ?, updated_at = CURRENT_TIMESTAMP 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $role);
        $stmt->bindParam(2, $id);
        
        return $stmt->execute();
    }
}
?>