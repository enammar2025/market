document.addEventListener('DOMContentLoaded', function() {
    // تغيير الصورة الرئيسية عند النقر على الصور المصغرة
    function changeMainImage(element) {
        const mainImage = document.getElementById('main-product-image');
        mainImage.src = element.src;
        
        // إزالة النشاط من جميع الصور المصغرة
        document.querySelectorAll('.thumbnail-img').forEach(img => {
            img.classList.remove('active');
        });
        
        // إضافة النشاط للصورة المحددة
        element.classList.add('active');
    }
    
    // تعيين الدالة للاستخدام العام (للاستدعاء من onclick في HTML)
    window.changeMainImage = changeMainImage;
    
    // زيادة ونقصان الكمية
    const quantityInput = document.getElementById('quantity');
    const incrementBtn = document.getElementById('increment');
    const decrementBtn = document.getElementById('decrement');
    
    if (incrementBtn && decrementBtn && quantityInput) {
        incrementBtn.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            const maxValue = parseInt(quantityInput.max);
            
            if (currentValue < maxValue) {
                quantityInput.value = currentValue + 1;
            }
        });
        
        decrementBtn.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            if (currentValue > 1) {
                quantityInput.value = currentValue - 1;
            }
        });
    }
    
    // إضافة إلى السلة
    const addToCartForm = document.querySelector('.add-to-cart-form');
    if (addToCartForm) {
        addToCartForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
           
            const productId = parseInt(addToCartForm.dataset.productId);

            const quantity = parseInt(quantityInput.value);
            
            // هنا يمكنك إضافة كود إرسال البيانات عبر AJAX
            fetch('add_to_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    product_id: productId,
                    quantity: quantity
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('تمت إضافة المنتج إلى السلة بنجاح');
                    // يمكنك هنا تحديث عداد السلة في القائمة
                } else {
                    alert('حدث خطأ: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ أثناء إضافة المنتج إلى السلة');
            });
        });
    }
});