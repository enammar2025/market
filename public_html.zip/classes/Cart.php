<?php
require_once 'config/database.php';

class Cart {
    private $conn;
    private $table_name = "carts";
    private $cart_items_table = "cart_items";

    public $id;
    public $user_id;
    public $session_id;
    public $coupon_code;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    // إنشاء سلة جديدة أو الحصول على السلة الموجودة
    public function getOrCreateCart($user_id = null, $session_id = null) {
        if ($user_id) {
            $query = "SELECT * FROM " . $this->table_name . " WHERE user_id = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
        } else {
            $query = "SELECT * FROM " . $this->table_name . " WHERE session_id = :session_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':session_id', $session_id);
        }
        
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            return $row['id'];
        } else {
            // إنشاء سلة جديدة
            $query = "INSERT INTO " . $this->table_name . " (user_id, session_id) VALUES (:user_id, :session_id)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':session_id', $session_id);
            
            if ($stmt->execute()) {
                return $this->conn->lastInsertId();
            }
        }
        
        return false;
    }

    // إضافة منتج إلى السلة
    public function addItem($cart_id, $product_id, $quantity, $price) {
        // التحقق من وجود المنتج في السلة
        $query = "SELECT * FROM " . $this->cart_items_table . " WHERE cart_id = :cart_id AND product_id = :product_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':cart_id', $cart_id);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            // تحديث الكمية
            $new_quantity = $row['quantity'] + $quantity;
            $query = "UPDATE " . $this->cart_items_table . " 
                      SET quantity = :quantity, updated_at = CURRENT_TIMESTAMP 
                      WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':quantity', $new_quantity);
            $stmt->bindParam(':id', $row['id']);
        } else {
            // إضافة منتج جديد
            $query = "INSERT INTO " . $this->cart_items_table . " 
                      (cart_id, product_id, quantity, price) 
                      VALUES (:cart_id, :product_id, :quantity, :price)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':cart_id', $cart_id);
            $stmt->bindParam(':product_id', $product_id);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->bindParam(':price', $price);
        }
        
        return $stmt->execute();
    }

    // الحصول على عناصر السلة
    public function getItems($cart_id) {
        $query = "SELECT ci.*, p.name, p.image, p.slug, p.stock_quantity 
                  FROM " . $this->cart_items_table . " ci 
                  JOIN products p ON ci.product_id = p.id 
                  WHERE ci.cart_id = :cart_id 
                  ORDER BY ci.created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':cart_id', $cart_id);
        $stmt->execute();
        
        return $stmt;
    }

    // تحديث كمية منتج في السلة
    public function updateItemQuantity($item_id, $quantity) {
        if ($quantity <= 0) {
            return $this->removeItem($item_id);
        }
        
        $query = "UPDATE " . $this->cart_items_table . " 
                  SET quantity = :quantity, updated_at = CURRENT_TIMESTAMP 
                  WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':quantity', $quantity);
        $stmt->bindParam(':id', $item_id);
        
        return $stmt->execute();
    }

    // حذف منتج من السلة
    public function removeItem($item_id) {
        $query = "DELETE FROM " . $this->cart_items_table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $item_id);
        
        return $stmt->execute();
    }

    // إفراغ السلة
    public function clearCart($cart_id) {
        $query = "DELETE FROM " . $this->cart_items_table . " WHERE cart_id = :cart_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':cart_id', $cart_id);
        
        return $stmt->execute();
    }

    // حساب إجمالي السلة
    public function getCartTotal($cart_id) {
        $query = "SELECT SUM(quantity * price) as total FROM " . $this->cart_items_table . " WHERE cart_id = :cart_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':cart_id', $cart_id);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] ?? 0;
    }

    // عد عناصر السلة
    public function getCartItemsCount($cart_id) {
        $query = "SELECT SUM(quantity) as count FROM " . $this->cart_items_table . " WHERE cart_id = :cart_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':cart_id', $cart_id);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['count'] ?? 0;
    }
}
?>