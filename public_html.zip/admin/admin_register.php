<?php
require_once __DIR__ . '/../includes/config.php'; // تأكد أن $pdo موجود في هذا الملف

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // جمع البيانات مع تعقيمها
    $username   = trim($_POST['username'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $password   = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name  = trim($_POST['last_name'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $address    = trim($_POST['address'] ?? '');

    // التحقق من الحقول المطلوبة
    if (!$username || !$email || !$password || !$confirm_password || !$first_name || !$last_name) {
        $message = "يرجى ملء جميع الحقول المطلوبة.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "البريد الإلكتروني غير صالح.";
    } elseif ($password !== $confirm_password) {
        $message = "كلمة المرور وتأكيدها غير متطابقين.";
    } else {
        try {
            // تحقق من تكرار اسم المستخدم أو البريد
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = :username OR email = :email");
            $stmt->execute([':username' => $username, ':email' => $email]);

            if ($stmt->fetchColumn() > 0) {
                $message = "اسم المستخدم أو البريد الإلكتروني مستخدم مسبقًا.";
            } else {
                // تشفير كلمة المرور
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // تعيين الدور والقيمة المناسبة للحالة (status=1)
                $role = 'admin';
                $status = 1;

                // إدخال البيانات
                $insert = $pdo->prepare("INSERT INTO users 
                    (username, email, password, first_name, last_name, phone, address, role, status, created_at, updated_at)
                    VALUES (:username, :email, :password, :first_name, :last_name, :phone, :address, :role, :status, NOW(), NOW())");

                $insert->execute([
                    ':username'   => $username,
                    ':email'      => $email,
                    ':password'   => $hashed_password,
                    ':first_name' => $first_name,
                    ':last_name'  => $last_name,
                    ':phone'      => $phone,
                    ':address'    => $address,
                    ':role'       => $role,
                    ':status'     => $status
                ]);

                $message = "تم تسجيل المشرف بنجاح. يمكنك الآن تسجيل الدخول.";
            }
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            $message = "حدث خطأ أثناء التسجيل، يرجى المحاولة لاحقًا.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>تسجيل مشرف جديد</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet" />
    <style>
        body {
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .register-form {
            background: white;
            padding: 2.5rem 3rem;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
            width: 100%;
            max-width: 480px;
        }
        h2 {
            font-weight: 700;
            margin-bottom: 1.8rem;
            color: #333;
            text-align: center;
        }
        .btn-primary {
            background: #2575fc;
            border: none;
            font-weight: 600;
            padding: 0.7rem;
            font-size: 1.1rem;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background: #195bcc;
        }
        .form-label {
            font-weight: 600;
            color: #444;
        }
        .alert {
            font-weight: 600;
        }
        footer {
            margin-top: 20px;
            text-align: center;
            color: white;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <form method="post" class="register-form" novalidate>
        <h2>تسجيل مشرف جديد</h2>

        <?php if ($message): ?>
            <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <div class="mb-3">
            <label for="username" class="form-label">اسم المستخدم *</label>
            <input type="text" id="username" name="username" class="form-control" required
                value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" />
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">البريد الإلكتروني *</label>
            <input type="email" id="email" name="email" class="form-control" required
                value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" />
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">كلمة المرور *</label>
            <input type="password" id="password" name="password" class="form-control" required />
        </div>

        <div class="mb-3">
            <label for="confirm_password" class="form-label">تأكيد كلمة المرور *</label>
            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required />
        </div>

        <div class="mb-3">
            <label for="first_name" class="form-label">الاسم الأول *</label>
            <input type="text" id="first_name" name="first_name" class="form-control" required
                value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" />
        </div>

        <div class="mb-3">
            <label for="last_name" class="form-label">الاسم الأخير *</label>
            <input type="text" id="last_name" name="last_name" class="form-control" required
                value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" />
        </div>

        <div class="mb-3">
            <label for="phone" class="form-label">رقم الهاتف</label>
            <input type="text" id="phone" name="phone" class="form-control"
                value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" />
        </div>

        <div class="mb-3">
            <label for="address" class="form-label">العنوان</label>
            <textarea id="address" name="address" class="form-control"><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary w-100">تسجيل مشرف جديد</button>
    </form>

    <footer>
        &copy; <?= date('Y') ?> موقعك | جميع الحقوق محفوظة
    </footer>
</body>
</html>
