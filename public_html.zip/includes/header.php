<nav class="navbar">
    <div class="container-fluid">
        <div class="navbar-brand">
            <a href="index.php">متجر الطاقة لمولدات الكهربائية</a>
        </div>
        <div class="navbar-menu">
            <a href="index.php">الرئيسية</a>
            <a href="products.php">المنتجات</a>
            <a href="contact.php">اتصل بنا</a>
            <a href="cart.php" class="cart-link">
                <i class="fas fa-shopping-cart"></i>
                السلة <span class="cart-count" id="cart-count">0</span>
            </a>
            
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="user-menu">
                    <span class="user-name">أهلاً <?php echo $_SESSION['first_name']; ?></span>
                    <?php if ($_SESSION['role'] == 'admin'): ?>
                        <a href="admin/dashboard.php">لوحة التحكم</a>
                    <?php endif; ?>
                    <a href="profile.php">الملف الشخصي</a>
                    <a href="logout.php">تسجيل الخروج</a>
                </div>
            <?php else: ?>
                <a href="login.php">تسجيل الدخول</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<style>
.navbar {
    background: #2c3e50; /* لون الخلفية */
    padding: 15px 0; /* المسافة من الأعلى والأسفل */
    box-shadow: 0 2px 10px rgba(0,0,0,0.1); /* ظل خفيف */
}

.navbar .container-fluid {
    display: flex; /* استخدام الفليكس لتوزيع العناصر */
    justify-content: space-between; /* توزيع العناصر بشكل متساوي */
    align-items: center; /* محاذاة العناصر عمودياً */
    padding: 0 20px; /* المسافة الجانبية */
}

.navbar-brand a {
    color: white; /* لون النص */
    text-decoration: none; /* إزالة التسطير */
    font-size: 24px; /* حجم الخط */
    font-weight: bold; /* سمك الخط */
}

.navbar-menu {
    display: flex; /* استخدام الفليكس لتوزيع العناصر */
    align-items: center; /* محاذاة العناصر عمودياً */
    gap: 25px; /* المسافة بين العناصر */
}

.navbar-menu a {
    color: white; /* لون النص */
    text-decoration: none; /* إزالة التسطير */
    padding: 8px 15px; /* المسافة الداخلية */
    border-radius: 5px; /* زوايا دائرية */
    transition: background 0.3s; /* تأثير الانتقال عند التمرير */
}

.navbar-menu a:hover {
    background: #34495e; /* لون الخلفية عند التمرير */
}

.cart-link {
    position: relative; /* لتحديد موضع السلة */
}

.cart-count {
    background: #e74c3c; /* لون الخلفية لعدد العناصر */
    color: white; /* لون النص */
    border-radius: 50%; /* شكل دائري */
    padding: 2px 6px; /* المسافة الداخلية */
    font-size: 12px; /* حجم الخط */
    position: absolute; /* موضع مطلق */
    top: -8px; /* المسافة من الأعلى */
    right: -8px; /* المسافة من اليمين */
}

.user-menu {
    position: relative; /* لتحديد موضع قائمة المستخدم */
    display: flex; /* استخدام الفليكس لتوزيع العناصر */
    align-items: center; /* محاذاة العناصر عمودياً */
    gap: 15px; /* المسافة بين العناصر */
}

.user-name {
    color: #ecf0f1; /* لون النص */
    font-weight: bold; /* سمك الخط */
}
</style>
