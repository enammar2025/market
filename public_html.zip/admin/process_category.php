<?php
require_once __DIR__ . '/../includes/config.php';

// استقبال القيم
$name = $_POST['name'] ?? '';
$slug = $_POST['slug'] ?? '';
$description = $_POST['description'] ?? '';
$parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;
$status = isset($_POST['status']) ? (int)$_POST['status'] : 1;

// التعامل مع الصورة
$imagePath = null;
if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $imageName = uniqid() . '.' . $ext;

    // تأكد من وجود المجلد uploads/categories
    $uploadDir = __DIR__ . '/../uploads/categories/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
    $imagePath = 'uploads/categories/' . $imageName;
}

try {
    $stmt = $pdo->prepare("INSERT INTO categories (name, slug, description, image, parent_id, status, created_at, updated_at)
                           VALUES (:name, :slug, :description, :image, :parent_id, :status, NOW(), NOW())");
    $stmt->execute([
        ':name' => $name,
        ':slug' => $slug,
        ':description' => $description,
        ':image' => $imagePath,
        ':parent_id' => $parent_id,
        ':status' => $status
    ]);

    header('Location: categories.php?success=1');
    exit;

} catch (PDOException $e) {
    echo "خطأ في الحفظ: " . $e->getMessage();
}
