<?php
session_start();
require_once '../config/database.php';
require_once '../classes/Category.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$category = new Category($db);

$message = '';
$message_type = '';

// معالجة العمليات
if ($_POST) {
    if (isset($_POST['add_category'])) {
        $name = $_POST['name'];
        $slug = $_POST['slug'];
        $description = $_POST['description'];
        $image = $_POST['image'];
        
        if ($category->create($name, $slug, $description, $image)) {
            $message = 'تم إضافة التصنيف بنجاح';
            $message_type = 'success';
        } else {
            $message = 'حدث خطأ في إضافة التصنيف';
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['update_category'])) {
        $id = $_POST['category_id'];
        $name = $_POST['name'];
        $slug = $_POST['slug'];
        $description = $_POST['description'];
        $image = $_POST['image'];
        
        if ($category->update($id, $name, $slug, $description, $image)) {
            $message = 'تم تحديث التصنيف بنجاح';
            $message_type = 'success';
        } else {
            $message = 'حدث خطأ في تحديث التصنيف';
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['delete_category'])) {
        $id = $_POST['category_id'];
        if ($category->delete($id)) {
            $message = 'تم حذف التصنيف بنجاح';
            $message_type = 'success';
        } else {
            $message = 'حدث خطأ في حذف التصنيف';
            $message_type = 'error';
        }
    }
}

$categories = $category->getAll();
$edit_category = null;
if (isset($_GET['edit'])) {
    $edit_category = $category->getById($_GET['edit']);
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة التصنيفات - متجر الطاقة الكهربائية</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .admin-container { display: flex; min-height: 100vh; background: #f8f9fa; }
        .admin-content { margin-right: 280px; padding: 30px; width: calc(100% - 280px); }
        .category-form { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 30px; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: bold; color: #333; }
        .form-group input, .form-group textarea { width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 8px; font-size: 16px; }
        .categories-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .category-card { background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .category-image { width: 100%; height: 200px; object-fit: cover; }
        .category-content { padding: 20px; }
        .category-actions { display: flex; gap: 10px; margin-top: 15px; }
        .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; font-size: 14px; }
        .btn-primary { background: #3498db; color: white; }
        .btn-warning { background: #f39c12; color: white; }
        .btn-danger { background: #e74c3c; color: white; }
        .btn-success { background: #27ae60; color: white; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 8px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'sidebar.php'; ?>

        <div class="admin-content">
            <h1>إدارة التصنيفات</h1>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="category-form">
                <h2><?php echo $edit_category ? 'تعديل التصنيف' : 'إضافة تصنيف جديد'; ?></h2>
                <form method="POST">
                    <?php if ($edit_category): ?>
                        <input type="hidden" name="category_id" value="<?php echo $edit_category['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="name">اسم التصنيف</label>
                            <input type="text" id="name" name="name" required 
                                   value="<?php echo $edit_category['name'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="slug">الرابط المختصر</label>
                            <input type="text" id="slug" name="slug" required 
                                   value="<?php echo $edit_category['slug'] ?? ''; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">وصف التصنيف</label>
                        <textarea id="description" name="description" required><?php echo $edit_category['description'] ?? ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="image">رابط صورة التصنيف</label>
                        <input type="url" id="image" name="image" 
                               value="<?php echo $edit_category['image'] ?? ''; ?>">
                    </div>
                    
                    <div class="category-actions">
                        <?php if ($edit_category): ?>
                            <button type="submit" name="update_category" class="btn btn-success">
                                تحديث التصنيف
                            </button>
                            <a href="categories.php" class="btn btn-primary">إلغاء</a>
                        <?php else: ?>
                            <button type="submit" name="add_category" class="btn btn-success">
                                إضافة التصنيف
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <h2>التصنيفات الحالية</h2>
            <div class="categories-grid">
                <?php foreach ($categories as $cat): ?>
                <div class="category-card">
                    <?php if ($cat['image']): ?>
                        <img src="<?php echo $cat['image']; ?>" alt="<?php echo $cat['name']; ?>" 
                             class="category-image" onerror="this.style.display='none'">
                    <?php endif; ?>
                    <div class="category-content">
                        <h3><?php echo $cat['name']; ?></h3>
                        <p><?php echo substr($cat['description'], 0, 100) . '...'; ?></p>
                        <div class="category-actions">
                            <a href="categories.php?edit=<?php echo $cat['id']; ?>" class="btn btn-warning">
                                <i class="fas fa-edit"></i> تعديل
                            </a>
                            <form method="POST" style="display: inline;" 
                                  onsubmit="return confirm('هل أنت متأكد من حذف هذا التصنيف؟')">
                                <input type="hidden" name="category_id" value="<?php echo $cat['id']; ?>">
                                <button type="submit" name="delete_category" class="btn btn-danger">
                                    <i class="fas fa-trash"></i> حذف
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script>
        // تحويل اسم التصنيف إلى slug تلقائياً
        document.getElementById('name').addEventListener('input', function() {
            const name = this.value;
            const slug = name.toLowerCase()
                            .replace(/[\u0600-\u06FF]/g, function(match) {
                                const arabicToEnglish = {
                                    'ا': 'a', 'ب': 'b', 'ت': 't', 'ث': 'th', 'ج': 'j',
                                    'ح': 'h', 'خ': 'kh', 'د': 'd', 'ذ': 'th', 'ر': 'r',
                                    'ز': 'z', 'س': 's', 'ش': 'sh', 'ص': 's', 'ض': 'd',
                                    'ط': 't', 'ظ': 'th', 'ع': 'a', 'غ': 'gh', 'ف': 'f',
                                    'ق': 'q', 'ك': 'k', 'ل': 'l', 'م': 'm', 'ن': 'n',
                                    'ه': 'h', 'و': 'w', 'ي': 'y'
                                };
                                return arabicToEnglish[match] || match;
                            })
                            .replace(/\s+/g, '-')
                            .replace(/[^\w\-]+/g, '');
            
            document.getElementById('slug').value = slug;
        });
    </script>
</body>
</html>