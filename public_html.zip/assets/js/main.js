// Mobile Menu Toggle
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const mobileMenu = document.querySelector('.mobile-menu');
const mobileMenuClose = document.querySelector('.mobile-menu-close');

mobileMenuBtn.addEventListener('click', () => {
    mobileMenu.style.right = '0';
});

mobileMenuClose.addEventListener('click', () => {
    mobileMenu.style.right = '-300px';
});

// Hero Slider
const heroSlides = document.querySelectorAll('.hero-slide');
const heroDots = document.querySelectorAll('.hero-slider-dots .dot');
const prevBtn = document.querySelector('.slider-prev');
const nextBtn = document.querySelector('.slider-next');
let currentSlide = 0;

function showSlide(index) {
    heroSlides.forEach(slide => slide.classList.remove('active'));
    heroDots.forEach(dot => dot.classList.remove('active'));
    
    heroSlides[index].classList.add('active');
    heroDots[index].classList.add('active');
    currentSlide = index;
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % heroSlides.length;
    showSlide(currentSlide);
}

function prevSlide() {
    currentSlide = (currentSlide - 1 + heroSlides.length) % heroSlides.length;
    showSlide(currentSlide);
}

nextBtn.addEventListener('click', nextSlide);
prevBtn.addEventListener('click', prevSlide);

heroDots.forEach((dot, index) => {
    dot.addEventListener('click', () => showSlide(index));
});

// Auto slide change
let slideInterval = setInterval(nextSlide, 5000);

// Pause on hover
const heroSlider = document.querySelector('.hero-slider');
heroSlider.addEventListener('mouseenter', () => clearInterval(slideInterval));
heroSlider.addEventListener('mouseleave', () => slideInterval = setInterval(nextSlide, 5000));

// Initialize first slide
showSlide(0);

// Back to Top Button
const backToTopBtn = document.getElementById('backToTop');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        backToTopBtn.classList.add('active');
    } else {
        backToTopBtn.classList.remove('active');
    }
});

backToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Quick View Modal
const quickViewModal = document.getElementById('quickViewModal');
const quickViewBtns = document.querySelectorAll('.quick-view');
const modalClose = document.querySelector('.modal-close');
const modalOverlay = document.querySelector('.modal-overlay');

function openQuickView(productId) {
    // Here you would typically fetch product details via AJAX
    // For demo purposes, we'll just show the modal
    quickViewModal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

quickViewBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const productId = btn.getAttribute('data-id');
        openQuickView(productId);
    });
});

function closeModal() {
    quickViewModal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

modalClose.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', closeModal);

// Close modal on ESC key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeModal();
    }
});

// Add to Cart Functionality
const addToCartBtns = document.querySelectorAll('.add-to-cart');
const cartCount = document.getElementById('cart-count');
const cartNotification = document.getElementById('cartNotification');

addToCartBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const productId = btn.getAttribute('data-id');
        const productName = btn.getAttribute('data-name');
        const productPrice = btn.getAttribute('data-price');
        
        // Here you would typically send this data to your server via AJAX
        // For demo purposes, we'll just update the UI
        
        // Update cart count
        let currentCount = parseInt(cartCount.textContent) || 0;
        cartCount.textContent = currentCount + 1;
        
        // Show notification
        cartNotification.classList.add('active');
        setTimeout(() => {
            cartNotification.classList.remove('active');
        }, 3000);
        
        // You can also store cart items in localStorage
        let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
        const existingItem = cartItems.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cartItems.push({
                id: productId,
                name: productName,
                price: productPrice,
                quantity: 1
            });
        }
        
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
    });
});

// Initialize cart count from localStorage
function initCartCount() {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    let totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
    cartCount.textContent = totalItems;
}

initCartCount();

// Quantity Selector
const quantityMinus = document.querySelector('.quantity-minus');
const quantityPlus = document.querySelector('.quantity-plus');
const quantityInput = document.querySelector('#quickViewQuantity');

if (quantityMinus && quantityPlus && quantityInput) {
    quantityMinus.addEventListener('click', () => {
        let value = parseInt(quantityInput.value);
        if (value > 1) {
            quantityInput.value = value - 1;
        }
    });
    
    quantityPlus.addEventListener('click', () => {
        let value = parseInt(quantityInput.value);
        quantityInput.value = value + 1;
    });
}

// Thumbnail Image Click
const thumbnails = document.querySelectorAll('.thumbnail-images img');
const mainImage = document.getElementById('quickViewMainImage');

thumbnails.forEach(thumb => {
    thumb.addEventListener('click', () => {
        mainImage.src = thumb.src;
    });
});

// Add to Wishlist
const addToWishlistBtns = document.querySelectorAll('.add-to-wishlist');

addToWishlistBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        const productId = this.getAttribute('data-id');
        
        // Here you would typically send this data to your server via AJAX
        // For demo purposes, we'll just toggle the icon
        if (this.classList.contains('active')) {
            this.innerHTML = '<i class="far fa-heart"></i>';
            this.classList.remove('active');
        } else {
            this.innerHTML = '<i class="fas fa-heart"></i>';
            this.classList.add('active');
        }
    });
});

// Product Filter
const sortSelect = document.querySelector('.sort-select');

if (sortSelect) {
    sortSelect.addEventListener('change', function() {
        // Here you would typically reload products with the new sorting
        // For demo purposes, we'll just log the selected value
        console.log('Sort by:', this.value);
    });
}