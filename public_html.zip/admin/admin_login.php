<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';

if (isLoggedIn() && isAdmin()) {
    error_log("Admin already logged in, redirecting to site_structure.php", 3, __DIR__ . "/../log.txt");
    header("Location: /site_structure.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = "يرجى إدخال اسم المستخدم وكلمة المرور.";
        error_log("Empty username or password", 3, __DIR__ . "/../log.txt");
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id, username, password, role FROM users WHERE username = :username LIMIT 1");
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                if ($user['role'] !== 'admin') {
                    $error = "ليس لديك صلاحيات المشرف.";
                    error_log("User {$username} is not admin, role: {$user['role']}", 3, __DIR__ . "/../log.txt");
                } else {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_role'] = $user['role'];
                    $_SESSION['username'] = $user['username'];
                    error_log("Login successful for user: {$username}", 3, __DIR__ . "/../log.txt");
                    header("Location: /site_structure.php");
                    exit;
                }
            } else {
                $error = "اسم المستخدم أو كلمة المرور غير صحيحة.";
                error_log("Invalid credentials for user: {$username}", 3, __DIR__ . "/../log.txt");
            }
        } catch (PDOException $e) {
            $error = "خطأ في قاعدة البيانات.";
            error_log("Database error: " . $e->getMessage(), 3, __DIR__ . "/../log.txt");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل دخول المشرف</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        body { background-color: #f0f0f0; }
        .login-container { max-width: 400px; margin: 100px auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
<div class="login-container">
    <h2 class="text-center mb-4">تسجيل دخول المشرف</h2>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="username" class="form-label">اسم المستخدم</label>
            <input type="text" name="username" id="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">كلمة المرور</label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">تسجيل الدخول</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
?>