<?php


require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';


$logFile = __DIR__ . "/../log.txt";
$userRole = $_SESSION['user_role'] ?? 'unset';
$method = $_SERVER['REQUEST_METHOD'] ?? 'unknown';

error_log("Attempting logout, Session ID: " . session_id() . ", user_role: $userRole, method: $method\n", 3, $logFile);

if ($method === 'POST') {
    $received = $_POST['csrf_token'] ?? 'unset';
    $expected = $_SESSION['logout_token'] ?? 'unset';
    if (isset($_POST['csrf_token'], $_SESSION['logout_token']) && hash_equals($expected, $received)) {
        logout(); // تأكد من أنها تدمر الجلسة وتعيد التوجيه مثلاً
    } else {
        error_log("CSRF token mismatch: received $received, expected $expected\n", 3, $logFile);
        http_response_code(403);
        die("خطأ: رمز CSRF غير صحيح.");
    }
} else {
    error_log("Invalid request method: $method\n", 3, $logFile);
    http_response_code(400);
    die("خطأ: طلب تسجيل خروج غير صالح.");
}
?>
