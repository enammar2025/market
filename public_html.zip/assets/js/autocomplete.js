// بحث ذكي (Autocomplete) باستخدام AJAX
const searchInput = document.getElementById('search-input');
const resultsBox = document.getElementById('autocomplete-results');
if (searchInput) {
  searchInput.addEventListener('input', function() {
    const query = this.value.trim();
    if (query.length > 1) {
      fetch(`search_autocomplete.php?query=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => {
          resultsBox.innerHTML = "";
          if (data.length === 0) {
            resultsBox.style.display = 'none';
            return;
          }
          resultsBox.style.display = 'block';
          data.forEach(item => {
            const div = document.createElement('div');
            div.classList.add('autocomplete-item');
            div.textContent = item.name;
            div.onclick = () => {
              searchInput.value = item.name;
              resultsBox.innerHTML = "";
              resultsBox.style.display = 'none';
            };
            resultsBox.appendChild(div);
          });
        });
    } else {
      resultsBox.innerHTML = "";
      resultsBox.style.display = 'none';
    }
  });
  document.body.addEventListener('click', () => {
    resultsBox.innerHTML = "";
    resultsBox.style.display = 'none';
  });
}