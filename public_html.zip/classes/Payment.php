<?php
class Payment {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }

    // محفظة رقمية محلية (مدى، STC Pay)
    public function processLocalWallet($order_id, $phone_number, $amount, $wallet_type = 'mada') {
        // محاكاة معالجة الدفع عبر المحفظة المحلية
        $transaction_id = 'TXN_' . time() . '_' . rand(1000, 9999);
        
        // هنا يتم التكامل مع API المحفظة الرقمية
        $payment_data = [
            'transaction_id' => $transaction_id,
            'order_id' => $order_id,
            'amount' => $amount,
            'phone_number' => $phone_number,
            'wallet_type' => $wallet_type,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        // محاكاة استجابة ناجحة
        if ($this->validatePhoneNumber($phone_number)) {
            $payment_data['status'] = 'completed';
            $this->updateOrderPaymentStatus($order_id, 'paid', $wallet_type);
            return [
                'success' => true,
                'transaction_id' => $transaction_id,
                'message' => 'تم الدفع بنجاح عبر ' . $this->getWalletName($wallet_type)
            ];
        }
        
        return [
            'success' => false,
            'message' => 'فشل في معالجة الدفع. تحقق من رقم الهاتف'
        ];
    }

    // الدفع عند التسليم
    public function processCOD($order_id, $delivery_address) {
        $this->updateOrderPaymentStatus($order_id, 'pending', 'cash_on_delivery');
        
        return [
            'success' => true,
            'message' => 'تم تأكيد طلبك. سيتم الدفع عند التسليم'
        ];
    }

    // تحويل بنكي
    public function processBankTransfer($order_id, $bank_name, $account_number, $amount) {
        $reference_number = 'REF_' . time() . '_' . rand(1000, 9999);
        
        // حفظ تفاصيل التحويل
        $transfer_data = [
            'order_id' => $order_id,
            'bank_name' => $bank_name,
            'account_number' => $account_number,
            'amount' => $amount,
            'reference_number' => $reference_number,
            'status' => 'pending_verification'
        ];
        
        $this->updateOrderPaymentStatus($order_id, 'pending', 'bank_transfer');
        
        return [
            'success' => true,
            'reference_number' => $reference_number,
            'message' => 'تم استلام طلب التحويل البنكي. رقم المرجع: ' . $reference_number
        ];
    }

    // فيزا/ماستركارد (محاكاة)
    public function processCreditCard($order_id, $card_number, $expiry_month, $expiry_year, $cvv, $amount) {
        // تشفير وحماية بيانات البطاقة
        $masked_card = '**** **** **** ' . substr($card_number, -4);
        
        // محاكاة معالجة البطاقة الائتمانية
        if ($this->validateCreditCard($card_number, $expiry_month, $expiry_year, $cvv)) {
            $transaction_id = 'CC_' . time() . '_' . rand(1000, 9999);
            
            $this->updateOrderPaymentStatus($order_id, 'paid', 'credit_card');
            
            return [
                'success' => true,
                'transaction_id' => $transaction_id,
                'masked_card' => $masked_card,
                'message' => 'تم الدفع بنجاح بالبطاقة الائتمانية'
            ];
        }
        
        return [
            'success' => false,
            'message' => 'بيانات البطاقة غير صحيحة'
        ];
    }

    private function validatePhoneNumber($phone) {
        // التحقق من صحة رقم الهاتف السعودي
        return preg_match('/^(05|5)[0-9]{8}$/', str_replace(['+966', '966', ' ', '-'], '', $phone));
    }

    private function validateCreditCard($card_number, $expiry_month, $expiry_year, $cvv) {
        // تحقق أساسي من بيانات البطاقة
        $card_number = preg_replace('/\s+/', '', $card_number);
        
        // طول البطاقة
        if (strlen($card_number) < 13 || strlen($card_number) > 19) {
            return false;
        }
        
        // تاريخ الانتهاء
        $current_year = date('Y');
        $current_month = date('n');
        
        if ($expiry_year < $current_year || ($expiry_year == $current_year && $expiry_month < $current_month)) {
            return false;
        }
        
        // CVV
        if (strlen($cvv) < 3 || strlen($cvv) > 4) {
            return false;
        }
        
        return true;
    }

    private function updateOrderPaymentStatus($order_id, $payment_status, $payment_gateway) {
        $query = "UPDATE orders 
                  SET payment_status = ?, payment_gateway = ?, updated_at = CURRENT_TIMESTAMP 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $payment_status);
        $stmt->bindParam(2, $payment_gateway);
        $stmt->bindParam(3, $order_id);
        
        return $stmt->execute();
    }

    private function getWalletName($wallet_type) {
        $wallets = [
            'mada' => 'مدى',
            'stc_pay' => 'STC Pay',
            'apple_pay' => 'Apple Pay',
            'google_pay' => 'Google Pay'
        ];
        
        return $wallets[$wallet_type] ?? $wallet_type;
    }

    public function getBankDetails() {
        return [
            'bank_name' => 'البنك الأهلي السعودي',
            'account_number' => 'SA12 1000 0000 0000 0000 0001',
            'account_name' => 'متجر الطاقة الكهربائية',
            'swift_code' => 'NCBKSARI'
        ];
    }

    public function getPaymentMethods() {
        return [
            'local_wallet' => [
                'name' => 'المحفظة الرقمية',
                'options' => ['mada', 'stc_pay', 'apple_pay'],
                'enabled' => true
            ],
            'credit_card' => [
                'name' => 'البطاقة الائتمانية',
                'options' => ['visa', 'mastercard'],
                'enabled' => true
            ],
            'bank_transfer' => [
                'name' => 'التحويل البنكي',
                'enabled' => true
            ],
            'cash_on_delivery' => [
                'name' => 'الدفع عند التسليم',
                'enabled' => true,
                'extra_fee' => 15.00
            ]
        ];
    }
}
?>