<?php
session_start();
require_once '../config/database.php';
require_once '../classes/Product.php';
require_once '../classes/Category.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);
$category = new Category($db);

$message = '';
$message_type = '';

// معالجة العمليات
if ($_POST) {
    if (isset($_POST['add_product'])) {
        $name = $_POST['name'];
        $slug = $_POST['slug'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $compare_price = $_POST['compare_price'] ?: null;
        $cost = $_POST['cost'] ?: null;
        $sku = $_POST['sku'];
        $category_id = $_POST['category_id'];
        $stock_quantity = $_POST['stock_quantity'];
        $image = $_POST['image'];
        
        if ($product->create($name, $slug, $description, $price, $compare_price, $cost, $sku, $category_id, $stock_quantity, $image)) {
            $message = 'تم إضافة المنتج بنجاح';
            $message_type = 'success';
        } else {
            $message = 'حدث خطأ في إضافة المنتج';
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['update_product'])) {
        $id = $_POST['product_id'];
        $updates = [
            'name' => $_POST['name'],
            'slug' => $_POST['slug'],
            'description' => $_POST['description'],
            'price' => $_POST['price'],
            'compare_price' => $_POST['compare_price'] ?: null,
            'cost' => $_POST['cost'] ?: null,
            'sku' => $_POST['sku'],
            'category_id' => $_POST['category_id'],
            'stock_quantity' => $_POST['stock_quantity'],
            'image' => $_POST['image']
        ];
        
        if ($product->update($id, $updates)) {
            $message = 'تم تحديث المنتج بنجاح';
            $message_type = 'success';
        } else {
            $message = 'حدث خطأ في تحديث المنتج';
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['delete_product'])) {
        $id = $_POST['product_id'];
        if ($product->delete($id)) {
            $message = 'تم حذف المنتج بنجاح';
            $message_type = 'success';
        } else {
            $message = 'حدث خطأ في حذف المنتج';
            $message_type = 'error';
        }
    }
}

// جلب البيانات
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$products_data = $product->getAll($page, 20);
$products = $products_data['products'];
$total_products = $products_data['total'];
$categories = $category->getAll();

$edit_product = null;
if (isset($_GET['edit'])) {
    $edit_product = $product->getById($_GET['edit']);
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المنتجات - متجر الطاقة الكهربائية</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .admin-container {
            display: flex;
            min-height: 100vh;
            background: #f8f9fa;
        }
        .admin-sidebar {
            width: 280px;
            background: #2c3e50;
            color: white;
            padding: 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        .admin-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
        }
        .product-form {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }
        .form-group textarea {
            height: 100px;
            resize: vertical;
        }
        .products-table {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .table-header {
            background: #34495e;
            color: white;
            padding: 20px;
        }
        .table-content {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            text-align: right;
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #f8f9fa;
            font-weight: bold;
            color: #2c3e50;
        }
        .product-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
        }
        .btn-group {
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #3498db;
            color: white;
        }
        .btn-success {
            background: #27ae60;
            color: white;
        }
        .btn-warning {
            background: #f39c12;
            color: white;
        }
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }
        .pagination a {
            padding: 8px 16px;
            background: white;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #333;
            border-radius: 5px;
        }
        .pagination a.active {
            background: #3498db;
            color: white;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'sidebar.php'; ?>

        <div class="admin-content">
            <h1>إدارة المنتجات</h1>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="product-form">
                <h2><?php echo $edit_product ? 'تعديل المنتج' : 'إضافة منتج جديد'; ?></h2>
                <form method="POST">
                    <?php if ($edit_product): ?>
                        <input type="hidden" name="product_id" value="<?php echo $edit_product['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="name">اسم المنتج</label>
                            <input type="text" id="name" name="name" required 
                                   value="<?php echo $edit_product['name'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="slug">الرابط المختصر</label>
                            <input type="text" id="slug" name="slug" required 
                                   value="<?php echo $edit_product['slug'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="sku">رمز المنتج (SKU)</label>
                            <input type="text" id="sku" name="sku" required 
                                   value="<?php echo $edit_product['sku'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="category_id">التصنيف</label>
                            <select id="category_id" name="category_id" required>
                                <option value="">اختر التصنيف</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>" 
                                            <?php echo ($edit_product && $edit_product['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
                                        <?php echo $cat['name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="price">السعر (ر.س)</label>
                            <input type="number" step="0.01" id="price" name="price" required 
                                   value="<?php echo $edit_product['price'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="compare_price">سعر المقارنة (اختياري)</label>
                            <input type="number" step="0.01" id="compare_price" name="compare_price" 
                                   value="<?php echo $edit_product['compare_price'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="cost">التكلفة (اختياري)</label>
                            <input type="number" step="0.01" id="cost" name="cost" 
                                   value="<?php echo $edit_product['cost'] ?? ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="stock_quantity">الكمية المتوفرة</label>
                            <input type="number" id="stock_quantity" name="stock_quantity" required 
                                   value="<?php echo $edit_product['stock_quantity'] ?? ''; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">وصف المنتج</label>
                        <textarea id="description" name="description" required><?php echo $edit_product['description'] ?? ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="image">رابط الصورة</label>
                        <input type="url" id="image" name="image" 
                               value="<?php echo $edit_product['image'] ?? ''; ?>">
                    </div>
                    
                    <div class="btn-group">
                        <?php if ($edit_product): ?>
                            <button type="submit" name="update_product" class="btn btn-success">
                                تحديث المنتج
                            </button>
                            <a href="products.php" class="btn btn-primary">إلغاء</a>
                        <?php else: ?>
                            <button type="submit" name="add_product" class="btn btn-success">
                                إضافة المنتج
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="products-table">
                <div class="table-header">
                    <h2>المنتجات الحالية (<?php echo $total_products; ?> منتج)</h2>
                </div>
                <div class="table-content">
                    <table>
                        <thead>
                            <tr>
                                <th>الصورة</th>
                                <th>اسم المنتج</th>
                                <th>التصنيف</th>
                                <th>السعر</th>
                                <th>المخزون</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $prod): ?>
                            <tr>
                                <td>
                                    <img src="<?php echo $prod['image']; ?>" alt="<?php echo $prod['name']; ?>" 
                                         class="product-image" onerror="this.src='../assets/images/placeholder.jpg'">
                                </td>
                                <td>
                                    <strong><?php echo $prod['name']; ?></strong><br>
                                    <small>SKU: <?php echo $prod['sku']; ?></small>
                                </td>
                                <td><?php echo $prod['category_name'] ?? 'غير محدد'; ?></td>
                                <td><?php echo number_format($prod['price'], 2); ?> ر.س</td>
                                <td>
                                    <span class="<?php echo $prod['stock_quantity'] < 5 ? 'text-danger' : 'text-success'; ?>">
                                        <?php echo $prod['stock_quantity']; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php echo $prod['status'] ? 'نشط' : 'غير نشط'; ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="products.php?edit=<?php echo $prod['id']; ?>" class="btn btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form method="POST" style="display: inline;" 
                                              onsubmit="return confirm('هل أنت متأكد من حذف هذا المنتج؟')">
                                            <input type="hidden" name="product_id" value="<?php echo $prod['id']; ?>">
                                            <button type="submit" name="delete_product" class="btn btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if ($total_products > 20): ?>
            <div class="pagination">
                <?php
                $total_pages = ceil($total_products / 20);
                for ($i = 1; $i <= $total_pages; $i++):
                ?>
                    <a href="products.php?page=<?php echo $i; ?>" 
                       class="<?php echo $page == $i ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // تحويل اسم المنتج إلى slug تلقائياً
        document.getElementById('name').addEventListener('input', function() {
            const name = this.value;
            const slug = name.toLowerCase()
                            .replace(/[\u0600-\u06FF]/g, function(match) {
                                // تحويل الأحرف العربية إلى إنجليزية
                                const arabicToEnglish = {
                                    'ا': 'a', 'ب': 'b', 'ت': 't', 'ث': 'th', 'ج': 'j',
                                    'ح': 'h', 'خ': 'kh', 'د': 'd', 'ذ': 'th', 'ر': 'r',
                                    'ز': 'z', 'س': 's', 'ش': 'sh', 'ص': 's', 'ض': 'd',
                                    'ط': 't', 'ظ': 'th', 'ع': 'a', 'غ': 'gh', 'ف': 'f',
                                    'ق': 'q', 'ك': 'k', 'ل': 'l', 'م': 'm', 'ن': 'n',
                                    'ه': 'h', 'و': 'w', 'ي': 'y'
                                };
                                return arabicToEnglish[match] || match;
                            })
                            .replace(/\s+/g, '-')
                            .replace(/[^\w\-]+/g, '');
            
            document.getElementById('slug').value = slug;
        });
    </script>
</body>
</html>