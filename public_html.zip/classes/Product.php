<?php
require_once 'config/database.php';

class Product {
    private $conn;
    private $table_name = "products";

    public $id;
    public $name;
    public $slug;
    public $description;
    public $price;
    public $compare_price;
    public $cost;
    public $sku;
    public $barcode;
    public $category_id;
    public $image;
    public $status;
    public $stock_quantity;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    // قراءة جميع المنتجات مع التصفية والبحث
    public function read($page = 1, $limit = 12, $category_id = null, $search = null) {
        $offset = ($page - 1) * $limit;
        
        $query = "SELECT p.*, c.name as category_name 
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.status = 1";
        
        $params = [];
        
        if ($category_id) {
            $query .= " AND p.category_id = :category_id";
            $params[':category_id'] = $category_id;
        }
        
        if ($search) {
            $query .= " AND (p.name LIKE :search OR p.description LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }
        
        $query .= " ORDER BY p.created_at DESC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        
        $stmt->execute();
        
        return $stmt;
    }

    // عد المنتجات الإجمالي
    public function count($category_id = null, $search = null) {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " WHERE status = 1";
        
        $params = [];
        
        if ($category_id) {
            $query .= " AND category_id = :category_id";
            $params[':category_id'] = $category_id;
        }
        
        if ($search) {
            $query .= " AND (name LIKE :search OR description LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $row['total'];
    }

    // قراءة منتج واحد
    public function readOne() {
        $query = "SELECT p.*, c.name as category_name 
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.id = :id AND p.status = 1 
                  LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $this->name = $row['name'];
            $this->slug = $row['slug'];
            $this->description = $row['description'];
            $this->price = $row['price'];
            $this->compare_price = $row['compare_price'];
            $this->cost = $row['cost'];
            $this->sku = $row['sku'];
            $this->barcode = $row['barcode'];
            $this->category_id = $row['category_id'];
            $this->image = $row['image'];
            $this->status = $row['status'];
            $this->stock_quantity = $row['stock_quantity'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            
            return true;
        }

        return false;
    }

    // قراءة منتج بواسطة الـ slug
    public function readBySlug($slug) {
        $query = "SELECT p.*, c.name as category_name 
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.slug = :slug AND p.status = 1 
                  LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':slug', $slug);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $this->id = $row['id'];
            $this->name = $row['name'];
            $this->slug = $row['slug'];
            $this->description = $row['description'];
            $this->price = $row['price'];
            $this->compare_price = $row['compare_price'];
            $this->cost = $row['cost'];
            $this->sku = $row['sku'];
            $this->barcode = $row['barcode'];
            $this->category_id = $row['category_id'];
            $this->image = $row['image'];
            $this->status = $row['status'];
            $this->stock_quantity = $row['stock_quantity'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            
            return $row;
        }

        return false;
    }

    // إنشاء منتج جديد
    public function create() {
        $query = "INSERT INTO " . $this->table_name . "
                  SET name=:name, slug=:slug, description=:description, 
                      price=:price, compare_price=:compare_price, cost=:cost,
                      sku=:sku, barcode=:barcode, category_id=:category_id,
                      image=:image, stock_quantity=:stock_quantity";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':slug', $this->slug);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':price', $this->price);
        $stmt->bindParam(':compare_price', $this->compare_price);
        $stmt->bindParam(':cost', $this->cost);
        $stmt->bindParam(':sku', $this->sku);
        $stmt->bindParam(':barcode', $this->barcode);
        $stmt->bindParam(':category_id', $this->category_id);
        $stmt->bindParam(':image', $this->image);
        $stmt->bindParam(':stock_quantity', $this->stock_quantity);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    // تحديث منتج
    public function update1() {
        $query = "UPDATE " . $this->table_name . "
                  SET name=:name, slug=:slug, description=:description, 
                      price=:price, compare_price=:compare_price, cost=:cost,
                      sku=:sku, barcode=:barcode, category_id=:category_id,
                      image=:image, stock_quantity=:stock_quantity,
                      updated_at=CURRENT_TIMESTAMP
                  WHERE id=:id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':slug', $this->slug);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':price', $this->price);
        $stmt->bindParam(':compare_price', $this->compare_price);
        $stmt->bindParam(':cost', $this->cost);
        $stmt->bindParam(':sku', $this->sku);
        $stmt->bindParam(':barcode', $this->barcode);
        $stmt->bindParam(':category_id', $this->category_id);
        $stmt->bindParam(':image', $this->image);
        $stmt->bindParam(':stock_quantity', $this->stock_quantity);
        $stmt->bindParam(':id', $this->id);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    // حذف منتج (إلغاء تفعيل)
    public function delete() {
        $query = "UPDATE " . $this->table_name . " SET status = 0 WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    // الحصول على المنتجات الأكثر مبيعاً
    public function getFeatured($limit = 6) {
        $query = "SELECT p.*, c.name as category_name 
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.status = 1 
                  ORDER BY p.created_at DESC 
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt;
    }

    // البحث في المنتجات
    public function search($keywords) {
        $query = "SELECT p.*, c.name as category_name 
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.status = 1 
                  AND (p.name LIKE :keywords OR p.description LIKE :keywords)
                  ORDER BY p.name";

        $stmt = $this->conn->prepare($query);
        $search_keywords = "%{$keywords}%";
        $stmt->bindParam(':keywords', $search_keywords);
        $stmt->execute();

        return $stmt;
    }

    public function update($id, $updates) {
        $set_clause = [];
        $params = [];
        
        foreach ($updates as $field => $value) {
            $set_clause[] = "$field = ?";
            $params[] = $value;
        }
        
        $params[] = $id;
        $query = "UPDATE " . $this->table_name . " SET " . implode(', ', $set_clause) . ", updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute($params);
    }

    public function deletecomplate($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        return $stmt->execute();
    }

    public function getTotalProducts() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }
}
?>