<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php'; // يحتوي على دالة isAdmin()

// التحقق من تسجيل الدخول وصلاحية المشرف
if (!isAdmin()) {
    header('Location: /admin/admin_login.php');
    exit;
}

$successMessage = '';
$errorMessage = '';

// عند استلام طلب POST (إرسال النموذج)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // استقبال القيم
    $name = $_POST['name'] ?? '';
    $slug = $_POST['slug'] ?? '';
    $description = $_POST['description'] ?? '';
    $parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;
    $status = isset($_POST['status']) ? (int)$_POST['status'] : 1;

    // التعامل مع الصورة
    $imagePath = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $imageName = uniqid() . '.' . $ext;

        $uploadDir = __DIR__ . '/../uploads/categories/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
        $imagePath = 'uploads/categories/' . $imageName;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO categories (name, slug, description, image, parent_id, status, created_at, updated_at)
                               VALUES (:name, :slug, :description, :image, :parent_id, :status, NOW(), NOW())");
        $stmt->execute([
            ':name' => $name,
            ':slug' => $slug,
            ':description' => $description,
            ':image' => $imagePath,
            ':parent_id' => $parent_id,
            ':status' => $status
        ]);

        $successMessage = 'تم حفظ الفئة بنجاح.';
    } catch (PDOException $e) {
        $errorMessage = 'خطأ في الحفظ: ' . $e->getMessage();
    }
}

// جلب الفئات لعرضها في الجدول
$categories = $pdo->query("SELECT c.*, p.name as parent_name 
                          FROM categories c 
                          LEFT JOIN categories p ON c.parent_id = p.id 
                          ORDER BY c.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الفئات - DoublePower</title>
    <!-- Bootstrap RTL CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Tajawal', sans-serif;
        }
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .main-content {
            padding: 20px;
        }
        .category-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        .status-active {
            background-color: #d4edda;
            color: #155724;
        }
        .status-inactive {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- الشريط الجانبي -->
        <div class="sidebar d-flex flex-column flex-shrink-0 p-3 text-white" style="width: 280px;">
            <a href="/admin" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                <i class="bi bi-speedometer2 me-2"></i>
                <span class="fs-4">لوحة التحكم</span>
            </a>
            <hr>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="/index.php" class="nav-link">
                        <i class="bi bi-house-door me-2"></i>
                        الرئيسية
                    </a>
                </li>
                <li>
                    <a href="admin_controlpanel.php" class="nav-link active">
                        <i class="bi bi-tags me-2"></i>
                        الفئات
                    </a>
                </li>
                <li>
                    <a href="/admin/dashboard.php" class="nav-link">
                        <i class="bi bi-box-seam me-2"></i>
                        المنتجات
                    </a>
                </li>
                <li>
                    <a href="/admin/orders" class="nav-link">
                        <i class="bi bi-cart-check me-2"></i>
                        الطلبات
                    </a>
                </li>
                <li>
                    <a href="/admin/users" class="nav-link">
                        <i class="bi bi-people me-2"></i>
                        المستخدمين
                    </a>
                </li>
            </ul>
            <hr>
            <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-person-circle me-2 fs-4"></i>
                    <strong><?= htmlspecialchars($_SESSION['admin_name'] ?? 'المشرف') ?></strong>
                </a>
                <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                    <li><a class="dropdown-item" href="#"><i class="bi bi-person me-2"></i>الملف الشخصي</a></li>
                    <li><a class="dropdown-item" href="#"><i class="bi bi-gear me-2"></i>الإعدادات</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="/admin/admin_logout.php"><i class="bi bi-box-arrow-left me-2"></i>تسجيل خروج</a></li>
                </ul>
            </div>
        </div>

        <!-- المحتوى الرئيسي -->
        <div class="main-content flex-grow-1">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="bi bi-tags me-2"></i>إدارة الفئات</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="categories.php?action=add" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-1"></i> إضافة فئة جديدة
                    </a>
                </div>
            </div>

            <?php if ($successMessage): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($successMessage) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($errorMessage): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($errorMessage) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0"><i class="bi bi-plus-circle me-2"></i>إضافة فئة جديدة</h5>
                        </div>
                        <div class="card-body">
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="name" class="form-label">اسم الفئة *</label>
                                    <input type="text" id="name" name="name" class="form-control" required maxlength="255">
                                </div>
                                <div class="mb-3">
                                    <label for="slug" class="form-label">الرابط المختصر (Slug)</label>
                                    <input type="text" id="slug" name="slug" class="form-control" maxlength="255">
                                    <small class="text-muted">سيتم إنشاؤه تلقائياً إذا ترك فارغاً</small>
                                </div>
                                <div class="mb-3">
                                    <label for="description" class="form-label">الوصف</label>
                                    <textarea id="description" name="description" class="form-control" rows="3"></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="image" class="form-label">صورة الفئة</label>
                                    <input type="file" id="image" name="image" accept="image/*" class="form-control">
                                    <small class="text-muted">الصور الموصى بها: 400x400 بكسل</small>
                                </div>
                                <div class="mb-3">
                                    <label for="parent_id" class="form-label">الفئة الرئيسية (إن وجدت)</label>
                                    <select id="parent_id" name="parent_id" class="form-select">
                                        <option value="">-- بدون --</option>
                                        <?php
                                        // جلب الفئات لعرضها في الاختيار كفئات رئيسية محتملة
                                        $stmt = $pdo->query("SELECT id, name FROM categories ORDER BY name");
                                        while ($cat = $stmt->fetch()) {
                                            echo '<option value="' . $cat['id'] . '">' . htmlspecialchars($cat['name']) . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="status" class="form-label">الحالة *</label>
                                    <select id="status" name="status" class="form-select" required>
                                        <option value="1" selected>نشط</option>
                                        <option value="0">غير نشط</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save me-1"></i> حفظ الفئة
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0"><i class="bi bi-list-ul me-2"></i>قائمة الفئات</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>الصورة</th>
                                            <th>الاسم</th>
                                            <th>الحالة</th>
                                            <th>إجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($categories as $category): ?>
                                        <tr>
                                            <td>
                                                <?php if ($category['image']): ?>
                                                    <img src="/<?= htmlspecialchars($category['image']) ?>" alt="<?= htmlspecialchars($category['name']) ?>" class="category-img">
                                                <?php else: ?>
                                                    <span class="text-muted">بدون صورة</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <strong><?= htmlspecialchars($category['name']) ?></strong>
                                                <?php if ($category['parent_name']): ?>
                                                    <br>
                                                    <small class="text-muted">تابع لـ: <?= htmlspecialchars($category['parent_name']) ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="status-badge <?= $category['status'] ? 'status-active' : 'status-inactive' ?>">
                                                    <?= $category['status'] ? 'نشط' : 'غير نشط' ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="categories.php?action=edit&id=<?= $category['id'] ?>" class="btn btn-sm btn-outline-primary me-1" title="تعديل">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="categories.php?action=delete&id=<?= $category['id'] ?>" class="btn btn-sm btn-outline-danger" title="حذف" onclick="return confirm('هل أنت متأكد من حذف هذه الفئة؟')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // توليد الرابط المختصر تلقائياً عند كتابة الاسم
        document.getElementById('name').addEventListener('input', function() {
            const slugInput = document.getElementById('slug');
            if (!slugInput.value) {
                slugInput.value = this.value.trim()
                    .toLowerCase()
                    .replace(/\s+/g, '-')
                    .replace(/[^\w\-]+/g, '')
                    .replace(/\-\-+/g, '-')
                    .replace(/^-+/, '')
                    .replace(/-+$/, '');
            }
        });
    </script>
</body>
</html>