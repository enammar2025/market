<?php
require_once __DIR__ . '/Database.php';

/**
 * تنفيذ تسجيل الخروج
 */
function logout(): void {
    error_log("Logout executed for user_id: " . ($_SESSION['user_id'] ?? 'unset'), 3, __DIR__ . "/../log.txt");
    session_unset();
    session_destroy();
    header('Location: /admin/admin_login.php?logout=success');
    exit;
}

/**
 * التحقق من تسجيل الدخول لأي دور
 * @return bool
 */
function isLoggedIn(): bool {
    $result = isset($_SESSION['user_id'], $_SESSION['user_role']);
    if (!$result) {
        error_log("isLoggedIn failed: user_id=" . ($_SESSION['user_id'] ?? 'unset') . ", user_role=" . ($_SESSION['user_role'] ?? 'unset'), 3, __DIR__ . "/../log.txt");
    }
    return $result;
}

class Auth {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    public function isAdmin() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin';
    }

    /**
     * تنظيف المدخلات لمنع الهجمات
     * @param string $data
     * @return string
     */
    public function sanitize_input(string $data): string {
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
}
?>
