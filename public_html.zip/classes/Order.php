<?php
class Order {
    private $conn;
    private $orders_table = "orders";
    private $order_items_table = "order_items";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function createOrder($user_id, $total, $payment_method, $shipping_address, $billing_address = null, $notes = '', $cart_items = []) {
        try {
            $this->conn->beginTransaction();
            
            // Generate order number
            $order_number = 'ORD-' . date('Y') . '-' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
            
            // Insert order
            $query = "INSERT INTO " . $this->orders_table . " 
                      (user_id, order_number, total, status, payment_method, payment_status, 
                       shipping_address, billing_address, notes, ip_address) 
                      VALUES (?, ?, ?, 'pending', ?, 'pending', ?, ?, ?, ?)";
            
            $stmt = $this->conn->prepare($query);
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $billing_address = $billing_address ?: $shipping_address;
            
            $stmt->bindParam(1, $user_id);
            $stmt->bindParam(2, $order_number);
            $stmt->bindParam(3, $total);
            $stmt->bindParam(4, $payment_method);
            $stmt->bindParam(5, $shipping_address);
            $stmt->bindParam(6, $billing_address);
            $stmt->bindParam(7, $notes);
            $stmt->bindParam(8, $ip_address);
            
            $stmt->execute();
            $order_id = $this->conn->lastInsertId();
            
            // Insert order items
            foreach ($cart_items as $item) {
                $item_query = "INSERT INTO " . $this->order_items_table . " 
                              (order_id, product_id, product_name, product_price, quantity, total) 
                              VALUES (?, ?, ?, ?, ?, ?)";
                
                $item_stmt = $this->conn->prepare($item_query);
                $item_total = $item['price'] * $item['quantity'];
                
                $item_stmt->bindParam(1, $order_id);
                $item_stmt->bindParam(2, $item['product_id']);
                $item_stmt->bindParam(3, $item['product_name']);
                $item_stmt->bindParam(4, $item['price']);
                $item_stmt->bindParam(5, $item['quantity']);
                $item_stmt->bindParam(6, $item_total);
                
                $item_stmt->execute();
            }
            
            $this->conn->commit();
            return $order_id;
            
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }

    public function getOrderById($id) {
        $query = "SELECT o.*, 
                         GROUP_CONCAT(
                             CONCAT(oi.product_name, ' (', oi.quantity, ' × ', oi.product_price, ')') 
                             SEPARATOR ', '
                         ) as items_summary
                  FROM " . $this->orders_table . " o
                  LEFT JOIN " . $this->order_items_table . " oi ON o.id = oi.order_id
                  WHERE o.id = ?
                  GROUP BY o.id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    public function getOrderItems($order_id) {
        $query = "SELECT * FROM " . $this->order_items_table . " WHERE order_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $order_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getUserOrders($user_id, $page = 1, $limit = 10) {
        $offset = ($page - 1) * $limit;
        
        $query = "SELECT * FROM " . $this->orders_table . " 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $user_id);
        $stmt->bindParam(2, $limit, PDO::PARAM_INT);
        $stmt->bindParam(3, $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllOrders($page = 1, $limit = 20, $status = null) {
        $offset = ($page - 1) * $limit;
        
        $where_clause = $status ? "WHERE o.status = ?" : "";
        
        $query = "SELECT o.*, u.username, u.first_name, u.last_name, u.email
                  FROM " . $this->orders_table . " o
                  LEFT JOIN users u ON o.user_id = u.id
                  $where_clause
                  ORDER BY o.created_at DESC 
                  LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($query);
        
        if ($status) {
            $stmt->bindParam(1, $status);
            $stmt->bindParam(2, $limit, PDO::PARAM_INT);
            $stmt->bindParam(3, $offset, PDO::PARAM_INT);
        } else {
            $stmt->bindParam(1, $limit, PDO::PARAM_INT);
            $stmt->bindParam(2, $offset, PDO::PARAM_INT);
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateOrderStatus($id, $status) {
        $query = "UPDATE " . $this->orders_table . " 
                  SET status = ?, updated_at = CURRENT_TIMESTAMP 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $status);
        $stmt->bindParam(2, $id);
        
        return $stmt->execute();
    }

    public function updatePaymentStatus($id, $payment_status, $payment_gateway = null) {
        $query = "UPDATE " . $this->orders_table . " 
                  SET payment_status = ?, payment_gateway = ?, updated_at = CURRENT_TIMESTAMP 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $payment_status);
        $stmt->bindParam(2, $payment_gateway);
        $stmt->bindParam(3, $id);
        
        return $stmt->execute();
    }

    public function getTotalOrders($status = null) {
        $where_clause = $status ? "WHERE status = ?" : "";
        $query = "SELECT COUNT(*) as total FROM " . $this->orders_table . " $where_clause";
        
        $stmt = $this->conn->prepare($query);
        if ($status) {
            $stmt->bindParam(1, $status);
        }
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }

    public function getOrdersStats() {
        $query = "SELECT 
                    COUNT(*) as total_orders,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
                    SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing_orders,
                    SUM(CASE WHEN status = 'shipped' THEN 1 ELSE 0 END) as shipped_orders,
                    SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) as delivered_orders,
                    SUM(CASE WHEN payment_status = 'paid' THEN total ELSE 0 END) as total_revenue,
                    AVG(total) as average_order_value
                  FROM " . $this->orders_table;
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getMonthlyRevenue($year = null) {
        $year = $year ?: date('Y');
        
        $query = "SELECT 
                    MONTH(created_at) as month,
                    SUM(CASE WHEN payment_status = 'paid' THEN total ELSE 0 END) as revenue
                  FROM " . $this->orders_table . "
                  WHERE YEAR(created_at) = ?
                  GROUP BY MONTH(created_at)
                  ORDER BY month";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $year);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>