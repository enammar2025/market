<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';

// التحقق من وجود الدالة
if (!function_exists('sanitize_input')) {
    error_log("الدالة sanitize_input غير معرفة", 3, __DIR__ . "/../log.txt");
    die("خطأ في الخادم: دالة تنظيف المدخلات مفقودة");
}

if (!isAdmin()) {
    $_SESSION['error_message'] = 'غير مصرح لك بالوصول.';
    header('Location: /admin/admin_login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error_message'] = 'طلب غير صالح.';
    include __DIR__ . '/admin-add_product.php';
    exit;
}

try {
    $pdo->beginTransaction();

    // تنظيف والتحقق من اسم المنتج
    if (empty($_POST['name']) || strlen(trim($_POST['name'])) < 2) {
        throw new Exception('اسم المنتج مطلوب ويجب أن يكون أطول من حرفين.');
    }
    $name = sanitize_input($_POST['name']);
    if (preg_match('/\.(jpg|png|webp|jpeg)$/i', $name)) {
        throw new Exception('اسم المنتج لا يمكن أن يكون اسم ملف صورة.');
    }

    $description = sanitize_input($_POST['description']);
    $price = (float)$_POST['price'];
    $compare_price = !empty($_POST['compare_price']) ? (float)$_POST['compare_price'] : null;
    $sku = sanitize_input($_POST['sku']);
    $category_id = (int)$_POST['category_id'];
    $stock_quantity = (int)$_POST['stock_quantity'];
    $status = (int)$_POST['status'];

    // التحقق من SKU
    $sku_stmt = $pdo->prepare("SELECT id FROM products WHERE sku = :sku");
    $sku_stmt->execute(['sku' => $sku]);
    if ($sku_stmt->fetch()) {
        throw new Exception('رمز SKU مستخدم بالفعل.');
    }

    // معالجة الصور
    $image_paths = [];
    $upload_dir = __DIR__ . '/../Uploads/products/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    $valid_types = ['image/jpeg', 'image/png', 'image/webp'];
    $max_size = 5 * 1024 * 1024; // 5MB

    foreach ($_FILES['images']['name'] as $key => $image_name) {
        if ($_FILES['images']['error'][$key] === UPLOAD_ERR_OK) {
            if (!in_array($_FILES['images']['type'][$key], $valid_types)) {
                throw new Exception('نوع الصورة غير مدعوم: ' . $image_name);
            }
            if ($_FILES['images']['size'][$key] > $max_size) {
                throw new Exception('حجم الصورة كبير جدًا: ' . $image_name);
            }
            $ext = pathinfo($image_name, PATHINFO_EXTENSION);
            $filename = 'prod_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            $target = $upload_dir . $filename;
            if (!move_uploaded_file($_FILES['images']['tmp_name'][$key], $target)) {
                throw new Exception('فشل رفع الصورة: ' . $image_name);
            }
            $image_paths[] = 'Uploads/products/' . $filename;
        }
    }
    if (empty($image_paths)) {
        throw new Exception('يجب رفع صورة واحدة على الأقل.');
    }

    // إنشاء slug
    $slug = generate_slug($name);
    $slug_stmt = $pdo->prepare("SELECT id FROM products WHERE slug = :slug");
    $slug_stmt->execute(['slug' => $slug]);
    if ($slug_stmt->fetch()) {
        $slug .= '-' . time();
    }

    // إدراج المنتج
    $product_stmt = $pdo->prepare("INSERT INTO products (name, slug, description, price, compare_price, sku, category_id, image, stock_quantity, status, created_at) VALUES (:name, :slug, :description, :price, :compare_price, :sku, :category_id, :image, :stock_quantity, :status, NOW())");
    $product_stmt->execute([
        'name' => $name,
        'slug' => $slug,
        'description' => $description,
        'price' => $price,
        'compare_price' => $compare_price,
        'sku' => $sku,
        'category_id' => $category_id,
        'image' => $image_paths[0],
        'stock_quantity' => $stock_quantity,
        'status' => $status
    ]);
    $product_id = $pdo->lastInsertId();

    // إدراج الصور الإضافية
    foreach ($image_paths as $sort_order => $path) {
        $image_stmt = $pdo->prepare("INSERT INTO product_images (product_id, image, sort_order) VALUES (:product_id, :image, :sort_order)");
        $image_stmt->execute(['product_id' => $product_id, 'image' => $path, 'sort_order' => $sort_order]);
    }

    // إدراج المواصفات
    if (!empty($_POST['specs'])) {
        foreach ($_POST['specs'] as $spec) {
            if (!empty($spec['key']) && !empty($spec['value'])) {
                $attr_stmt = $pdo->prepare("INSERT INTO product_attributes (product_id, attribute_name, attribute_value) VALUES (:product_id, :name, :value)");
                $attr_stmt->execute([
                    'product_id' => $product_id,
                    'name' => sanitize_input($spec['key']),
                    'value' => sanitize_input($spec['value'])
                ]);
            }
        }
    }

    // إدراج الخصم
    if (!empty($_POST['discount_type']) && !empty($_POST['discount_value'])) {
        $discount_stmt = $pdo->prepare("INSERT INTO product_discounts (product_id, discount_type, discount_value, start_date, end_date) VALUES (:product_id, :discount_type, :discount_value, :start_date, :end_date)");
        $discount_stmt->execute([
            'product_id' => $product_id,
            'discount_type' => $_POST['discount_type'],
            'discount_value' => (float)$_POST['discount_value'],
            'start_date' => $_POST['discount_start'] ?: null,
            'end_date' => $_POST['discount_end'] ?: null
        ]);
    }

    // تسجيل النشاط
    $log_stmt = $pdo->prepare("INSERT INTO activity_log (user_id, action, details, ip_address, user_agent, created_at) VALUES (:user_id, :action, :details, :ip, :ua, NOW())");
    $log_stmt->execute([
        'user_id' => $_SESSION['user_id'],
        'action' => 'add_product',
        'details' => "إضافة منتج جديد: $name (ID: $product_id)",
        'ip' => $_SERVER['REMOTE_ADDR'],
        'ua' => $_SERVER['HTTP_USER_AGENT']
    ]);

    $pdo->commit();
    $_SESSION['success_message'] = 'تم الحفظ بنجاح: ' . htmlspecialchars($name);
    $_SESSION['show_buttons'] = true; // إشارة لعرض الأزرار
    include __DIR__ . '/admin-add_product.php'; // الإبقاء على نفس الصفحة
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    error_log("خطأ في process_product.php: " . $e->getMessage(), 3, __DIR__ . "/../log.txt");
    $_SESSION['error_message'] = $e->getMessage();
    include __DIR__ . '/admin-add_product.php'; // الإبقاء على نفس الصفحة في حالة الخطأ
    exit;
}
?>