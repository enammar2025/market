// JavaScript للوحة الإدارة
class AdminDashboard {
    constructor() {
        this.initCharts();
        this.initNotifications();
        this.initQuickActions();
    }

    // رسوم بيانية للإحصائيات
    initCharts() {
        // رسم الإيرادات الشهرية (محاكاة)
        const revenueChart = document.getElementById('revenue-chart');
        if (revenueChart) {
            this.createRevenueChart();
        }

        // رسم توزيع الطلبات
        const ordersChart = document.getElementById('orders-chart');
        if (ordersChart) {
            this.createOrdersChart();
        }
    }

    createRevenueChart() {
        // محاكاة بيانات الإيرادات الشهرية
        const monthlyData = [
            { month: 'يناير', revenue: 45000 },
            { month: 'فبراير', revenue: 52000 },
            { month: 'مارس', revenue: 48000 },
            { month: 'أبريل', revenue: 61000 },
            { month: 'مايو', revenue: 55000 },
            { month: 'يونيو', revenue: 67000 }
        ];

        // إنشاء رسم بياني بسيط
        const chartContainer = document.getElementById('revenue-chart');
        if (chartContainer) {
            chartContainer.innerHTML = this.generateBarChart(monthlyData);
        }
    }

    generateBarChart(data) {
        const maxRevenue = Math.max(...data.map(item => item.revenue));
        let html = '<div class="bar-chart">';
        
        data.forEach(item => {
            const height = (item.revenue / maxRevenue) * 200;
            html += `
                <div class="bar-item">
                    <div class="bar" style="height: ${height}px;" data-value="${item.revenue}"></div>
                    <div class="bar-label">${item.month}</div>
                </div>
            `;
        });
        
        html += '</div>';
        return html;
    }

    createOrdersChart() {
        // رسم دائري لحالات الطلبات
        const orderStates = {
            'في الانتظار': 25,
            'قيد المعالجة': 40,
            'تم الشحن': 20,
            'تم التسليم': 15
        };

        const chartContainer = document.getElementById('orders-chart');
        if (chartContainer) {
            chartContainer.innerHTML = this.generatePieChart(orderStates);
        }
    }

    generatePieChart(data) {
        let html = '<div class="pie-chart-legend">';
        const colors = ['#3498db', '#f39c12', '#e74c3c', '#27ae60'];
        let index = 0;
        
        for (const [label, value] of Object.entries(data)) {
            html += `
                <div class="legend-item">
                    <span class="legend-color" style="background: ${colors[index]}"></span>
                    <span class="legend-label">${label}: ${value}%</span>
                </div>
            `;
            index++;
        }
        
        html += '</div>';
        return html;
    }

    // نظام الإشعارات
    initNotifications() {
        this.checkLowStock();
        this.checkPendingOrders();
        this.setupRealTimeUpdates();
    }

    checkLowStock() {
        // فحص المنتجات قليلة المخزون
        fetch('../api/check-stock.php')
            .then(response => response.json())
            .then(data => {
                if (data.low_stock_items && data.low_stock_items.length > 0) {
                    this.showNotification(
                        'تحذير: يوجد ' + data.low_stock_items.length + ' منتج بمخزون قليل',
                        'warning'
                    );
                }
            })
            .catch(error => console.log('خطأ في فحص المخزون:', error));
    }

    checkPendingOrders() {
        // فحص الطلبات المعلقة
        fetch('../api/pending-orders.php')
            .then(response => response.json())
            .then(data => {
                if (data.pending_count > 0) {
                    this.updatePendingOrdersBadge(data.pending_count);
                }
            })
            .catch(error => console.log('خطأ في فحص الطلبات:', error));
    }

    updatePendingOrdersBadge(count) {
        const badge = document.querySelector('.pending-orders-badge');
        if (badge) {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'inline' : 'none';
        }
    }

    setupRealTimeUpdates() {
        // تحديث البيانات كل 30 ثانية
        setInterval(() => {
            this.refreshDashboardStats();
        }, 30000);
    }

    refreshDashboardStats() {
        fetch('../api/dashboard-stats.php')
            .then(response => response.json())
            .then(data => {
                this.updateStatCards(data);
            })
            .catch(error => console.log('خطأ في تحديث الإحصائيات:', error));
    }

    updateStatCards(data) {
        // تحديث بطاقات الإحصائيات
        const stats = {
            'total-orders': data.total_orders,
            'total-revenue': data.total_revenue,
            'total-users': data.total_users,
            'total-products': data.total_products
        };

        for (const [id, value] of Object.entries(stats)) {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = this.formatNumber(value);
            }
        }
    }

    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    // الإجراءات السريعة
    initQuickActions() {
        this.setupBulkActions();
        this.setupQuickEdit();
        this.setupExportFeatures();
    }

    setupBulkActions() {
        const selectAllCheckbox = document.getElementById('select-all');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', (e) => {
                const checkboxes = document.querySelectorAll('.item-checkbox');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = e.target.checked;
                });
                this.updateBulkActionButtons();
            });
        }

        // مراقبة تغييرات الاختيار
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('item-checkbox')) {
                this.updateBulkActionButtons();
            }
        });
    }

    updateBulkActionButtons() {
        const selectedItems = document.querySelectorAll('.item-checkbox:checked');
        const bulkActions = document.querySelector('.bulk-actions');
        
        if (bulkActions) {
            bulkActions.style.display = selectedItems.length > 0 ? 'block' : 'none';
        }
    }

    setupQuickEdit() {
        // تعديل سريع للمنتجات
        document.addEventListener('dblclick', (e) => {
            if (e.target.classList.contains('editable')) {
                this.enableQuickEdit(e.target);
            }
        });
    }

    enableQuickEdit(element) {
        const currentValue = element.textContent;
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentValue;
        input.className = 'quick-edit-input';
        
        element.replaceWith(input);
        input.focus();
        input.select();

        const saveEdit = () => {
            const newValue = input.value;
            element.textContent = newValue;
            input.replaceWith(element);
            this.saveQuickEdit(element.dataset.id, element.dataset.field, newValue);
        };

        input.addEventListener('blur', saveEdit);
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                saveEdit();
            }
        });
    }

    saveQuickEdit(id, field, value) {
        const formData = new FormData();
        formData.append('id', id);
        formData.append('field', field);
        formData.append('value', value);

        fetch('../api/quick-edit.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.showNotification('تم الحفظ بنجاح', 'success');
            } else {
                this.showNotification('حدث خطأ في الحفظ', 'error');
            }
        })
        .catch(error => {
            this.showNotification('حدث خطأ في الاتصال', 'error');
        });
    }

    setupExportFeatures() {
        const exportBtn = document.getElementById('export-data');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportData();
            });
        }
    }

    exportData() {
        const currentPage = window.location.pathname.split('/').pop();
        let exportUrl = '../api/export.php?type=';

        if (currentPage.includes('products')) {
            exportUrl += 'products';
        } else if (currentPage.includes('orders')) {
            exportUrl += 'orders';
        } else if (currentPage.includes('users')) {
            exportUrl += 'users';
        }

        // إنشاء رابط تحميل
        const downloadLink = document.createElement('a');
        downloadLink.href = exportUrl;
        downloadLink.download = `export_${new Date().getTime()}.csv`;
        downloadLink.click();

        this.showNotification('جاري تحضير ملف التصدير...', 'info');
    }

    // عرض الإشعارات
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.remove()">×</button>
        `;

        const container = document.getElementById('notifications-container') || document.body;
        container.appendChild(notification);

        // إزالة الإشعار تلقائياً بعد 5 ثوان
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    // مساعدات عامة
    confirmDelete(message = 'هل أنت متأكد من الحذف؟') {
        return confirm(message);
    }

    formatCurrency(amount) {
        return new Intl.NumberFormat('ar-SA', {
            style: 'currency',
            currency: 'SAR'
        }).format(amount);
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ar-SA');
    }
}

// تهيئة لوحة الإدارة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    if (document.body.classList.contains('admin-page')) {
        new AdminDashboard();
    }
});

// إضافة CSS للرسوم البيانية والإشعارات
const adminStyles = `
<style>
.bar-chart {
    display: flex;
    align-items: end;
    justify-content: space-around;
    height: 200px;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 8px;
}

.bar-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
    margin: 0 5px;
}

.bar {
    background: linear-gradient(to top, #3498db, #5dade2);
    width: 30px;
    border-radius: 4px 4px 0 0;
    transition: all 0.3s ease;
    cursor: pointer;
}

.bar:hover {
    background: linear-gradient(to top, #2980b9, #3498db);
    transform: scale(1.05);
}

.bar-label {
    margin-top: 10px;
    font-size: 12px;
    color: #666;
    text-align: center;
}

.pie-chart-legend {
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 20px;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 10px;
}

.legend-color {
    width: 16px;
    height: 16px;
    border-radius: 3px;
}

.notification {
    position: fixed;
    top: 20px;
    left: 20px;
    padding: 15px 20px;
    border-radius: 8px;
    color: white;
    z-index: 10000;
    min-width: 300px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.notification-success { background: #27ae60; }
.notification-error { background: #e74c3c; }
.notification-warning { background: #f39c12; }
.notification-info { background: #3498db; }

.notification-close {
    background: none;
    border: none;
    color: white;
    font-size: 18px;
    cursor: pointer;
    margin-right: -5px;
}

.quick-edit-input {
    border: 2px solid #3498db;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: inherit;
    width: 100%;
}

.bulk-actions {
    display: none;
    background: #34495e;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.bulk-actions button {
    background: #3498db;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    margin-left: 10px;
    cursor: pointer;
}
</style>
`;

// إضافة الأنماط للصفحة
document.head.insertAdjacentHTML('beforeend', adminStyles);