<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit;
}

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$type = $_GET['type'] ?? 'overview';
$period = $_GET['period'] ?? '30'; // أيام

switch ($type) {
    case 'overview':
        $data = getOverviewStats($db, $period);
        break;
    case 'sales':
        $data = getSalesAnalytics($db, $period);
        break;
    case 'products':
        $data = getProductAnalytics($db, $period);
        break;
    case 'customers':
        $data = getCustomerAnalytics($db, $period);
        break;
    default:
        $data = ['error' => 'نوع التحليل غير مدعوم'];
}

echo json_encode($data, JSON_UNESCAPED_UNICODE);

function getOverviewStats($db, $period) {
    $start_date = date('Y-m-d', strtotime("-{$period} days"));
    
    // إجمالي الطلبات
    $orders_query = "SELECT COUNT(*) as total, SUM(total) as revenue 
                     FROM orders WHERE created_at >= ?";
    $stmt = $db->prepare($orders_query);
    $stmt->execute([$start_date]);
    $orders_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // العملاء الجدد
    $users_query = "SELECT COUNT(*) as new_users FROM users WHERE created_at >= ?";
    $stmt = $db->prepare($users_query);
    $stmt->execute([$start_date]);
    $users_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // المنتجات الأكثر مبيعاً
    $products_query = "SELECT p.name, SUM(oi.quantity) as sold 
                       FROM order_items oi 
                       JOIN products p ON oi.product_id = p.id 
                       JOIN orders o ON oi.order_id = o.id 
                       WHERE o.created_at >= ? 
                       GROUP BY p.id 
                       ORDER BY sold DESC LIMIT 5";
    $stmt = $db->prepare($products_query);
    $stmt->execute([$start_date]);
    $top_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return [
        'period' => $period,
        'total_orders' => $orders_data['total'],
        'total_revenue' => $orders_data['revenue'],
        'new_customers' => $users_data['new_users'],
        'top_products' => $top_products
    ];
}

function getSalesAnalytics($db, $period) {
    $start_date = date('Y-m-d', strtotime("-{$period} days"));
    
    // المبيعات اليومية
    $daily_query = "SELECT DATE(created_at) as date, COUNT(*) as orders, SUM(total) as revenue 
                    FROM orders WHERE created_at >= ? 
                    GROUP BY DATE(created_at) 
                    ORDER BY date";
    $stmt = $db->prepare($daily_query);
    $stmt->execute([$start_date]);
    $daily_sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // المبيعات حسب طريقة الدفع
    $payment_query = "SELECT payment_method, COUNT(*) as count, SUM(total) as revenue 
                      FROM orders WHERE created_at >= ? 
                      GROUP BY payment_method";
    $stmt = $db->prepare($payment_query);
    $stmt->execute([$start_date]);
    $payment_methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return [
        'daily_sales' => $daily_sales,
        'payment_methods' => $payment_methods
    ];
}

function getProductAnalytics($db, $period) {
    $start_date = date('Y-m-d', strtotime("-{$period} days"));
    
    // المنتجات الأكثر مبيعاً
    $best_sellers = "SELECT p.name, p.price, SUM(oi.quantity) as sold, 
                     SUM(oi.quantity * oi.product_price) as revenue 
                     FROM order_items oi 
                     JOIN products p ON oi.product_id = p.id 
                     JOIN orders o ON oi.order_id = o.id 
                     WHERE o.created_at >= ? 
                     GROUP BY p.id 
                     ORDER BY sold DESC LIMIT 10";
    $stmt = $db->prepare($best_sellers);
    $stmt->execute([$start_date]);
    $best_selling = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // المنتجات قليلة المخزون
    $low_stock = "SELECT name, stock_quantity FROM products 
                  WHERE stock_quantity < 10 AND status = 1 
                  ORDER BY stock_quantity ASC";
    $stmt = $db->prepare($low_stock);
    $stmt->execute();
    $low_stock_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return [
        'best_selling' => $best_selling,
        'low_stock' => $low_stock_items
    ];
}

function getCustomerAnalytics($db, $period) {
    $start_date = date('Y-m-d', strtotime("-{$period} days"));
    
    // أفضل العملاء
    $top_customers = "SELECT u.first_name, u.last_name, u.email, 
                      COUNT(o.id) as orders_count, SUM(o.total) as total_spent 
                      FROM users u 
                      JOIN orders o ON u.id = o.user_id 
                      WHERE o.created_at >= ? 
                      GROUP BY u.id 
                      ORDER BY total_spent DESC LIMIT 10";
    $stmt = $db->prepare($top_customers);
    $stmt->execute([$start_date]);
    $top_customers_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // العملاء الجدد
    $new_customers = "SELECT first_name, last_name, email, created_at 
                      FROM users WHERE created_at >= ? 
                      ORDER BY created_at DESC LIMIT 10";
    $stmt = $db->prepare($new_customers);
    $stmt->execute([$start_date]);
    $new_customers_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return [
        'top_customers' => $top_customers_data,
        'new_customers' => $new_customers_data
    ];
}
?>