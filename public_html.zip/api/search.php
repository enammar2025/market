<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../classes/Product.php';

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$category_id = isset($_GET['category']) ? (int)$_GET['category'] : null;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;

if (strlen($query) < 2) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب أن يكون البحث أكثر من حرفين',
        'results' => []
    ]);
    exit;
}

try {
    $results = [];
    
    // البحث في المنتجات
    $search_query = "SELECT p.id, p.name, p.slug, p.price, p.image, c.name as category_name
                     FROM products p 
                     LEFT JOIN categories c ON p.category_id = c.id
                     WHERE p.status = 1 
                     AND (p.name LIKE :query OR p.description LIKE :query OR p.sku LIKE :query)";
    
    if ($category_id) {
        $search_query .= " AND p.category_id = :category_id";
    }
    
    $search_query .= " ORDER BY 
                       CASE 
                         WHEN p.name LIKE :exact_query THEN 1
                         WHEN p.name LIKE :start_query THEN 2
                         ELSE 3
                       END,
                       p.name ASC
                       LIMIT :limit";
    
    $stmt = $db->prepare($search_query);
    $search_term = '%' . $query . '%';
    $exact_term = $query;
    $start_term = $query . '%';
    
    $stmt->bindParam(':query', $search_term);
    $stmt->bindParam(':exact_query', $exact_term);
    $stmt->bindParam(':start_query', $start_term);
    
    if ($category_id) {
        $stmt->bindParam(':category_id', $category_id);
    }
    
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $results[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'slug' => $row['slug'],
            'price' => number_format($row['price'], 2),
            'image' => $row['image'],
            'category' => $row['category_name'],
            'url' => 'product.php?slug=' . $row['slug']
        ];
    }
    
    // البحث في التصنيفات أيضاً
    $category_query = "SELECT id, name, slug 
                       FROM categories 
                       WHERE status = 1 
                       AND (name LIKE :query OR description LIKE :query)
                       LIMIT 3";
    
    $stmt = $db->prepare($category_query);
    $stmt->bindParam(':query', $search_term);
    $stmt->execute();
    
    $categories = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $categories[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'slug' => $row['slug'],
            'type' => 'category',
            'url' => 'index.php?category=' . $row['id']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'query' => $query,
        'products' => $results,
        'categories' => $categories,
        'total_products' => count($results),
        'total_categories' => count($categories)
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'حدث خطأ في البحث',
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>