<?php
session_start();
require_once '../config/database.php';
require_once '../classes/Order.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$order = new Order($db);

$message = '';
$message_type = '';

// معالجة تحديث حالة الطلب
if ($_POST && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    
    if ($order->updateOrderStatus($order_id, $new_status)) {
        $message = 'تم تحديث حالة الطلب بنجاح';
        $message_type = 'success';
    } else {
        $message = 'حدث خطأ في تحديث الطلب';
        $message_type = 'error';
    }
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$status_filter = $_GET['status'] ?? null;

$orders = $order->getAllOrders($page, 20, $status_filter);
$total_orders = $order->getTotalOrders($status_filter);
$order_stats = $order->getOrdersStats();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الطلبات - متجر الطاقة الكهربائية</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .admin-container { display: flex; min-height: 100vh; background: #f8f9fa; }
        .admin-content { margin-right: 280px; padding: 30px; width: calc(100% - 280px); }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
        .stat-value { font-size: 28px; font-weight: bold; color: #2c3e50; }
        .stat-label { color: #7f8c8d; font-size: 14px; margin-top: 5px; }
        .filters { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        .filter-group { display: flex; gap: 15px; align-items: center; }
        .orders-table { background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .table-header { background: #34495e; color: white; padding: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: right; padding: 15px; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; font-weight: bold; color: #2c3e50; }
        .status-badge { padding: 6px 12px; border-radius: 15px; font-size: 12px; font-weight: bold; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-processing { background: #d4edda; color: #155724; }
        .status-shipped { background: #d1ecf1; color: #0c5460; }
        .status-delivered { background: #d4edda; color: #155724; }
        .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; font-size: 14px; }
        .btn-primary { background: #3498db; color: white; }
        .btn-success { background: #27ae60; color: white; }
        .btn-warning { background: #f39c12; color: white; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 8px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'sidebar.php'; ?>

        <div class="admin-content">
            <h1>إدارة الطلبات</h1>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $order_stats['total_orders']; ?></div>
                    <div class="stat-label">إجمالي الطلبات</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $order_stats['pending_orders']; ?></div>
                    <div class="stat-label">في الانتظار</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $order_stats['processing_orders']; ?></div>
                    <div class="stat-label">قيد المعالجة</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo number_format($order_stats['total_revenue'], 2); ?> ر.س</div>
                    <div class="stat-label">إجمالي الإيرادات</div>
                </div>
            </div>

            <div class="filters">
                <form method="GET" class="filter-group">
                    <label for="status">تصفية حسب الحالة:</label>
                    <select name="status" id="status" onchange="this.form.submit()">
                        <option value="">جميع الحالات</option>
                        <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>في الانتظار</option>
                        <option value="processing" <?php echo $status_filter == 'processing' ? 'selected' : ''; ?>>قيد المعالجة</option>
                        <option value="shipped" <?php echo $status_filter == 'shipped' ? 'selected' : ''; ?>>تم الشحن</option>
                        <option value="delivered" <?php echo $status_filter == 'delivered' ? 'selected' : ''; ?>>تم التسليم</option>
                    </select>
                    <a href="orders.php" class="btn btn-primary">إعادة تعيين</a>
                </form>
            </div>

            <div class="orders-table">
                <div class="table-header">
                    <h2>قائمة الطلبات (<?php echo $total_orders; ?> طلب)</h2>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>رقم الطلب</th>
                            <th>العميل</th>
                            <th>المبلغ</th>
                            <th>طريقة الدفع</th>
                            <th>الحالة</th>
                            <th>التاريخ</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order_item): ?>
                        <tr>
                            <td><?php echo $order_item['order_number']; ?></td>
                            <td>
                                <?php echo $order_item['first_name'] . ' ' . $order_item['last_name']; ?><br>
                                <small><?php echo $order_item['email']; ?></small>
                            </td>
                            <td><?php echo number_format($order_item['total'], 2); ?> ر.س</td>
                            <td>
                                <?php
                                $payment_methods = [
                                    'local_wallet' => 'المحفظة الرقمية',
                                    'credit_card' => 'البطاقة الائتمانية',
                                    'bank_transfer' => 'التحويل البنكي',
                                    'cash_on_delivery' => 'الدفع عند التسليم'
                                ];
                                echo $payment_methods[$order_item['payment_method']] ?? $order_item['payment_method'];
                                ?>
                            </td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="order_id" value="<?php echo $order_item['id']; ?>">
                                    <select name="status" onchange="this.form.submit()">
                                        <option value="pending" <?php echo $order_item['status'] == 'pending' ? 'selected' : ''; ?>>في الانتظار</option>
                                        <option value="processing" <?php echo $order_item['status'] == 'processing' ? 'selected' : ''; ?>>قيد المعالجة</option>
                                        <option value="shipped" <?php echo $order_item['status'] == 'shipped' ? 'selected' : ''; ?>>تم الشحن</option>
                                        <option value="delivered" <?php echo $order_item['status'] == 'delivered' ? 'selected' : ''; ?>>تم التسليم</option>
                                        <option value="cancelled" <?php echo $order_item['status'] == 'cancelled' ? 'selected' : ''; ?>>ملغي</option>
                                    </select>
                                    <input type="hidden" name="update_status" value="1">
                                </form>
                            </td>
                            <td><?php echo date('Y-m-d H:i', strtotime($order_item['created_at'])); ?></td>
                            <td>
                                <a href="order-details.php?id=<?php echo $order_item['id']; ?>" class="btn btn-primary">
                                    <i class="fas fa-eye"></i> عرض
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_orders > 20): ?>
            <div class="pagination" style="display: flex; justify-content: center; gap: 10px; margin-top: 20px;">
                <?php
                $total_pages = ceil($total_orders / 20);
                for ($i = 1; $i <= $total_pages; $i++):
                ?>
                    <a href="orders.php?page=<?php echo $i; ?><?php echo $status_filter ? '&status=' . $status_filter : ''; ?>" 
                       class="btn <?php echo $page == $i ? 'btn-success' : 'btn-primary'; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>