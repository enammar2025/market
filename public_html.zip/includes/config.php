<?php
// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'u647818269_PowerMarket');
define('DB_USER', 'u647818269_enammar2025');
define('DB_PASS', '#Hind@Osama2020!');
define('DB_CHARSET', 'utf8mb4');

// الاتصال بقاعدة البيانات
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("Database connection error: " . $e->getMessage(), 3, __DIR__ . "/../log.txt");
    die("خطأ في الاتصال بقاعدة البيانات.");
}

// إعدادات الموقع
define('SITE_NAME', 'متجر الطاقة والمولدات');
define('SITE_URL', 'https://doublepower.org'); // استبدل بالنطاق الصحيح
define('ADMIN_EMAIL', 'admin@doublepower.org'); // استبدل بالبريد الإلكتروني الصحيح
define('CURRENCY', 'ر.س');

// إعدادات الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Riyadh');

// إعدادات التطبيق
define('ITEMS_PER_PAGE', 12);
define('DEBUG_MODE', true);

// مسارات الملفات
define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/');
define('PRODUCT_IMG_DIR', UPLOAD_DIR . 'products/');
define('CATEGORY_IMG_DIR', UPLOAD_DIR . 'categories/');
define('DEFAULT_PRODUCT_IMG', '/assets/images/default-product.jpg');

// تأكد من وجود مجلدات التحميل
if (!file_exists(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
if (!file_exists(PRODUCT_IMG_DIR)) mkdir(PRODUCT_IMG_DIR, 0755, true);
if (!file_exists(CATEGORY_IMG_DIR)) mkdir(CATEGORY_IMG_DIR, 0755, true);
?>