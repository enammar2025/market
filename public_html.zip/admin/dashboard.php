<?php
session_start();
require_once '../config/database.php';
require_once '../classes/User.php';
require_once '../classes/Product.php';
require_once '../classes/Order.php';

// التحقق من تسجيل الدخول وصلاحيات الإدارة
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user = new User($db);
$product = new Product($db);
$order = new Order($db);

// إحصائيات عامة
$orders_stats = $order->getOrdersStats();
$total_users = $user->getTotalUsers();
$total_products = $product->getTotalProducts();

// الطلبات الحديثة
$recent_orders = $order->getAllOrders(1, 5);

// الإيرادات الشهرية
$monthly_revenue = $order->getMonthlyRevenue();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - متجر الطاقة الكهربائية</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .admin-container {
            display: flex;
            min-height: 100vh;
            background: #f8f9fa;
        }
        .admin-sidebar {
            width: 280px;
            background: #2c3e50;
            color: white;
            padding: 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        .admin-header {
            padding: 20px;
            background: #34495e;
            border-bottom: 1px solid #455a64;
        }
        .admin-menu {
            padding: 0;
        }
        .admin-menu a {
            display: block;
            padding: 15px 20px;
            color: #ecf0f1;
            text-decoration: none;
            border-bottom: 1px solid #34495e;
            transition: background 0.3s;
        }
        .admin-menu a:hover, .admin-menu a.active {
            background: #3498db;
        }
        .admin-menu i {
            width: 20px;
            margin-left: 10px;
        }
        .admin-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            margin: 0 0 10px 0;
            color: #7f8c8d;
            font-size: 14px;
            font-weight: normal;
        }
        .stat-card .stat-value {
            font-size: 32px;
            font-weight: bold;
            color: #2c3e50;
        }
        .stat-card .stat-change {
            font-size: 12px;
            margin-top: 5px;
        }
        .stat-change.positive { color: #27ae60; }
        .stat-change.negative { color: #e74c3c; }
        .admin-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .admin-section h2 {
            margin: 0 0 20px 0;
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }
        .orders-table th,
        .orders-table td {
            text-align: right;
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        .orders-table th {
            background: #f8f9fa;
            font-weight: bold;
            color: #2c3e50;
        }
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-processing { background: #d4edda; color: #155724; }
        .status-shipped { background: #d1ecf1; color: #0c5460; }
        .status-delivered { background: #d4edda; color: #155724; }
        .revenue-chart {
            height: 300px;
            background: #f8f9fa;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-sidebar">
            <div class="admin-header">
                <h3>لوحة التحكم</h3>
                <p>أهلاً <?php echo $_SESSION['first_name']; ?></p>
            </div>
            <nav class="admin-menu">
                <a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> الرئيسية</a>
                <a href="products.php"><i class="fas fa-box"></i> المنتجات</a>
                <a href="orders.php"><i class="fas fa-shopping-cart"></i> الطلبات</a>
                <a href="users.php"><i class="fas fa-users"></i> المستخدمين</a>
                <a href="categories.php"><i class="fas fa-tags"></i> التصنيفات</a>
                <a href="settings.php"><i class="fas fa-cog"></i> الإعدادات</a>
                <a href="../index.php"><i class="fas fa-home"></i> عرض المتجر</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
            </nav>
        </div>

        <div class="admin-content">
            <h1>لوحة التحكم الرئيسية</h1>

            <div class="stats-grid">
                <div class="stat-card">
                    <h3>إجمالي الطلبات</h3>
                    <div class="stat-value"><?php echo number_format($orders_stats['total_orders']); ?></div>
                    <div class="stat-change positive">+12% من الشهر الماضي</div>
                </div>
                <div class="stat-card">
                    <h3>إجمالي الإيرادات</h3>
                    <div class="stat-value"><?php echo number_format($orders_stats['total_revenue'], 2); ?> ر.س</div>
                    <div class="stat-change positive">+8.5% من الشهر الماضي</div>
                </div>
                <div class="stat-card">
                    <h3>المستخدمين المسجلين</h3>
                    <div class="stat-value"><?php echo number_format($total_users); ?></div>
                    <div class="stat-change positive">+24 مستخدم جديد</div>
                </div>
                <div class="stat-card">
                    <h3>المنتجات المتاحة</h3>
                    <div class="stat-value"><?php echo number_format($total_products); ?></div>
                    <div class="stat-change">جميع المنتجات متاحة</div>
                </div>
            </div>

            <div class="admin-section">
                <h2>الطلبات الحديثة</h2>
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>رقم الطلب</th>
                            <th>العميل</th>
                            <th>المبلغ</th>
                            <th>الحالة</th>
                            <th>التاريخ</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_orders as $order): ?>
                        <tr>
                            <td><?php echo $order['order_number']; ?></td>
                            <td><?php echo $order['first_name'] . ' ' . $order['last_name']; ?></td>
                            <td><?php echo number_format($order['total'], 2); ?> ر.س</td>
                            <td>
                                <span class="status-badge status-<?php echo $order['status']; ?>">
                                    <?php 
                                    $statuses = [
                                        'pending' => 'في الانتظار',
                                        'processing' => 'قيد المعالجة',
                                        'shipped' => 'تم الشحن',
                                        'delivered' => 'تم التسليم'
                                    ];
                                    echo $statuses[$order['status']] ?? $order['status'];
                                    ?>
                                </span>
                            </td>
                            <td><?php echo date('Y-m-d', strtotime($order['created_at'])); ?></td>
                            <td>
                                <a href="order-details.php?id=<?php echo $order['id']; ?>" class="btn btn-small">عرض</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="admin-section">
                <h2>الإيرادات الشهرية</h2>
                <div class="revenue-chart">
                    <p>سيتم إضافة مخطط الإيرادات هنا</p>
                    <small>الإيرادات للعام الحالي: <?php echo number_format($orders_stats['total_revenue'], 2); ?> ر.س</small>
                </div>
            </div>
        </div>
    </div>
</body>
</html>