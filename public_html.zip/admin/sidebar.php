<div class="admin-sidebar">
    <div class="admin-header">
        <h3>لوحة التحكم</h3>
        <p>أهلاً <?php echo $_SESSION['first_name']; ?></p>
    </div>
    <nav class="admin-menu">
        <a href="dashboard.php" <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'class="active"' : ''; ?>>
            <i class="fas fa-tachometer-alt"></i> الرئيسية
        </a>
        <a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>
            <i class="fas fa-box"></i> المنتجات
        </a>
        <a href="orders.php" <?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'class="active"' : ''; ?>>
            <i class="fas fa-shopping-cart"></i> الطلبات
        </a>
        <a href="users.php" <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'class="active"' : ''; ?>>
            <i class="fas fa-users"></i> المستخدمين
        </a>
        <a href="categories.php" <?php echo basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'class="active"' : ''; ?>>
            <i class="fas fa-tags"></i> التصنيفات
        </a>
        <a href="settings.php" <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'class="active"' : ''; ?>>
            <i class="fas fa-cog"></i> الإعدادات
        </a>
        <a href="../index.php"><i class="fas fa-home"></i> عرض المتجر</a>
        <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
    </nav>
</div>

<style>
.admin-sidebar {
    width: 280px;
    background: #2c3e50;
    color: white;
    padding: 0;
    position: fixed;
    height: 100vh;
    overflow-y: auto;
}
.admin-header {
    padding: 20px;
    background: #34495e;
    border-bottom: 1px solid #455a64;
}
.admin-menu {
    padding: 0;
}
.admin-menu a {
    display: block;
    padding: 15px 20px;
    color: #ecf0f1;
    text-decoration: none;
    border-bottom: 1px solid #34495e;
    transition: background 0.3s;
}
.admin-menu a:hover, .admin-menu a.active {
    background: #3498db;
}
.admin-menu i {
    width: 20px;
    margin-left: 10px;
}
</style>