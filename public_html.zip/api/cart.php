<?php
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../classes/Cart.php';

// إنشاء الاتصال بقاعدة البيانات
$database = new Database();
$db = $database->getConnection();

if (!$db) {
    echo json_encode(['success' => false, 'message' => 'فشل الاتصال بقاعدة البيانات']);
    exit;
}

$cart = new Cart($db);

// الحصول على معرف الجلسة
$session_id = session_id();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// الحصول على معرف السلة أو إنشاء سلة جديدة
$cart_id = $cart->getOrCreateCart($user_id, $session_id);

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        try {
            $items = $cart->getItems($cart_id);
            $cart_items = [];
            
            while ($row = $items->fetch(PDO::FETCH_ASSOC)) {
                $cart_items[] = $row;
            }
            
            $total = $cart->getCartTotal($cart_id);
            $count = $cart->getCartItemsCount($cart_id);
            
            echo json_encode([
                'success' => true,
                'items' => $cart_items,
                'total' => $total,
                'count' => $count
            ]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطأ في جلب عناصر السلة']);
        }
        break;
        
    case 'POST':
        $action = $input['action'] ?? '';
        
        if ($action === 'add') {
            $product_id = $input['product_id'] ?? 0;
            $quantity = $input['quantity'] ?? 1;
            $price = $input['price'] ?? 0;
            
            if ($product_id && $price > 0) {
                try {
                    $result = $cart->addItem($cart_id, $product_id, $quantity, $price);
                    
                    if ($result) {
                        $count = $cart->getCartItemsCount($cart_id);
                        echo json_encode([
                            'success' => true,
                            'message' => 'تم إضافة المنتج إلى السلة',
                            'count' => $count
                        ]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'فشل في إضافة المنتج']);
                    }
                } catch (Exception $e) {
                    echo json_encode(['success' => false, 'message' => 'خطأ في إضافة المنتج']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
            }
        } elseif ($action === 'update') {
            $item_id = $input['item_id'] ?? 0;
            $quantity = $input['quantity'] ?? 1;
            
            if ($item_id) {
                try {
                    $result = $cart->updateItemQuantity($item_id, $quantity);
                    
                    if ($result || $quantity == 0) {
                        $count = $cart->getCartItemsCount($cart_id);
                        $total = $cart->getCartTotal($cart_id);
                        echo json_encode([
                            'success' => true,
                            'message' => 'تم تحديث الكمية',
                            'count' => $count,
                            'total' => $total
                        ]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'فشل في تحديث الكمية']);
                    }
                } catch (Exception $e) {
                    echo json_encode(['success' => false, 'message' => 'خطأ في تحديث الكمية']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'معرف غير صالح']);
            }
        } elseif ($action === 'remove') {
            $item_id = $input['item_id'] ?? 0;
            
            if ($item_id) {
                try {
                    $result = $cart->removeItem($item_id);
                    
                    if ($result) {
                        $count = $cart->getCartItemsCount($cart_id);
                        $total = $cart->getCartTotal($cart_id);
                        echo json_encode([
                            'success' => true,
                            'message' => 'تم حذف المنتج',
                            'count' => $count,
                            'total' => $total
                        ]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'فشل في حذف المنتج']);
                    }
                } catch (Exception $e) {
                    echo json_encode(['success' => false, 'message' => 'خطأ في حذف المنتج']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'معرف غير صالح']);
            }
        } elseif ($action === 'clear') {
            try {
                $result = $cart->clearCart($cart_id);
                
                if ($result) {
                    echo json_encode([
                        'success' => true,
                        'message' => 'تم إفراغ السلة',
                        'count' => 0,
                        'total' => 0
                    ]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'فشل في إفراغ السلة']);
                }
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'message' => 'خطأ في إفراغ السلة']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'إجراء غير معروف']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'طريقة غير مدعومة']);
        break;
}
?>